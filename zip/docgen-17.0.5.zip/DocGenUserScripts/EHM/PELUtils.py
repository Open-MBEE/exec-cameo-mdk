from com.nomagic.magicdraw.core import Application
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from com.nomagic.magicdraw.openapi.uml import SessionManager
from com.nomagic.magicdraw.openapi.uml import ModelElementsManager
from com.nomagic.uml2.ext.jmi.helpers import ModelHelper
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import Enumeration
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import AggregationKindEnum
from com.nomagic.uml2.ext.magicdraw.compositestructures.mdports import Port
from com.nomagic.magicdraw.teamwork.application import TeamworkUtils
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Lifeline
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import StateInvariant
from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import State
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import ElementValue
from com.nomagic.uml2.ext.magicdraw.commonbehaviors.mdsimpletime import DurationConstraint
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import Generalization

from javax.swing import JOptionPane
from javax.swing import JCheckBox
from java.lang import Object
from jarray import array
import sys
import traceback
import os

from gov.nasa.jpl.mbee.lib import Utils
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTable
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBText
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBColSpec
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTableEntry
from gov.nasa.jpl.mbee import DocGenUtils
from gov.nasa.jpl.mel import PELTable as PELTablej
from gov.nasa.jpl.mel import ModelLib

from gov.nasa.jpl.mgss.mbee.docgen.table import EditableTable
from gov.nasa.jpl.mgss.mbee.docgen.table import PropertyEnum

contingencys = "contingency"
cbes = "steady-state power CBE"
mevs = "steady-state power MEV"

def findProperty(plc, pname):
    '''find a property in power load characterization based on name'''
    if plc:
        for p in plc.getOwnedAttribute():
            if p.getName() == pname:
                return p
    return None

def sortByNameKey(e):
    '''key function for sorting, this is what's used for comparison'''
    return e.getName()

def findWpPLCForMode(wp, m, wp2plc):
    '''wp is workpackage, m is name of mode'''
    for plc in wp2plc.get(wp):
        if plc.getName() == m:
            return plc

def findLifelineIncludingInherited(i, prop):
    inherited = Utils.collectDirectedRelatedElementsByRelationshipJavaClass(i, Generalization, 1, 0)
    inherited.add(i)
    for interaction in inherited:
        for e in interaction.getOwnedElement():
            if isinstance(e, Lifeline) and e.getRepresents() == prop:
                return e
    return None    
    
def findLifeline(prop, mode, product, p2i):
    if p2i.get(product).containsKey(mode):
        interaction = p2i.get(product).get(mode)
        return findLifelineIncludingInherited(interaction, prop)
        #for e in interaction.getOwnedElement():
         #   if isinstance(e, Lifeline) and e.getRepresents() == prop:
          #      return e
    return None

def getPLCForState(state):
    submachine = state.getSubmachine()
    if submachine is None:

        for char in Utils.collectDirectedRelatedElementsByRelationshipStereotypeString(state, ModelLib.CHARACTERIZES, 2, True, 1):
            if (ModelLib.isCharacterization(char) and PELTablej.extendsFromSteadyStatePower(char)):
                return char
    else:
        return submachine

def getStatePlcs2percent(lifeline):
    states = {}

    for cover in lifeline.getCoveredBy():
        if isinstance(cover, StateInvariant):
            constraint = cover.getInvariant()
            if constraint is not None and isinstance(constraint.getSpecification(), ElementValue) and isinstance(constraint.getSpecification().getElement(), State):
                duration = []
                state = constraint.getSpecification().getElement()

                plc = getPLCForState(state)

                #put this in for now so it doesn't cause exceptions
                #if state is None:
                #    continue
                per = None
                for durCon in cover.get_constraintOfConstrainedElement():
                    if isinstance(durCon, DurationConstraint):
                        durInt = durCon.getSpecification()
                        durMin = durInt.getMin()
                        expr = durMin.getExpr()
                        percent = expr.getValue().split("%")
                        if len(percent) > 0:
                            try:
                                per = float(percent[0])
                            except:
                                pass
                if per is None:
                    per = 100
                if state not in states:
                    states[plc] = per  
                else:
                    states[plc] = states[plc] + per  
    return states

def getCombinedPlcName(plcs):
    names = [e.getName() for e in plcs.keys()]
    return ', '.join(sorted(names))

def getCombinedPlcCbe(plcs):
    ccbe = 0
    for plc in plcs.keys():
        cbe = findProperty(plc, cbes)
        if cbe is not None and cbe.getDefault() is not None:
            percent = plcs[plc]
            ccbe += float(cbe.getDefault())*percent/100
    return ccbe

def getCombinedPlcContingency(plcs):
    mev = getCombinedPlcMev(plcs)
    cbe = getCombinedPlcCbe(plcs)
    if cbe != 0:
        return Utils.floatTruncate(str(mev/cbe - 1), 2)
    return None

def getCombinedPlcMev(plcs):
    cmev = 0
    for plc in plcs.keys():
        mev = findProperty(plc, mevs)
        if mev is not None and mev.getDefault() is not None:
            percent = plcs[plc]
            cmev += float(mev.getDefault())*percent/100
    return cmev