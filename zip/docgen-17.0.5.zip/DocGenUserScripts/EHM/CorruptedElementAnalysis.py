from com.nomagic.magicdraw.core import Application
from com.nomagic.magicdraw.openapi.uml import SessionManager
from com.nomagic.magicdraw.openapi.uml import ModelElementsManager
from com.nomagic.magicdraw.openapi.uml import PresentationElementsManager

from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import *
from com.nomagic.uml2.ext.magicdraw.classes.mddependencies import *
from com.nomagic.uml2.ext.magicdraw.classes.mdinterfaces import *
from com.nomagic.uml2.ext.magicdraw.actions.mdbasicactions import *
from com.nomagic.uml2.ext.magicdraw.activities.mdbasicactivities import *
from com.nomagic.uml2.ext.magicdraw.activities.mdintermediateactivities import *
from com.nomagic.uml2.ext.magicdraw.auxiliaryconstructs.mdinformationflows import *
from com.nomagic.uml2.ext.magicdraw.activities.mdfundamentalactivities import *
from com.nomagic.uml2.ext.magicdraw.interactions.mdfragments import *
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import *
from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import *
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper, ModelHelper


from com.nomagic.magicdraw.core import *        # for ProjectUtilities which gets attached projects
from com.nomagic.magicdraw.dependency import *  # for DependencyCheckerHelper

from gov.nasa.jpl.mgss.mbee.docgen.validation import ValidationRule
from gov.nasa.jpl.mgss.mbee.docgen.validation import ValidationSuite
from gov.nasa.jpl.mgss.mbee.docgen.validation import ViolationSeverity

import com.nomagic.magicdraw.core.ApplicationEnvironment as ApplicationEnvironment


import sys, traceback

from gov.nasa.jpl.mbee.lib import Utils

gl = Application.getInstance().getGUILog()

# logging levels as globals...
ERROR   = 0
WARNING = 1
INFO    = 2
LOG_STRINGS = ["ERROR", "WARNING", "INFO"]
DGVIEW_ST = "view"

# need to specify how to correct property types
TYPE_MAP = {"contingency":"Real",
            "steady-state power CBE": "W",
            "steady-state power MEV": "W",
            }

class CorruptedElementAnalysis:
    
    def __init__(self):
        '''
        Constructor initializes member variables
        '''
        self.debugLevel = INFO

        # Grab all project and application specific managers
        self.gl = Application.getInstance().getGUILog()
        self.project = Application.getInstance().getProject()
        
        self.vs = ValidationSuite("Corrupted Element validation")
        self.corruptVr = ValidationRule("Corrupted element", "Corrupted Element", ViolationSeverity.WARNING)
        self.vs.addValidationRule(self.corruptVr)
                
        
    def log(self, level, message):
        '''
        Debugging feature that only logs when self.debugLevel is greater than the log message level
        @param level:    Level of the log message
        @param message:  String to be logged
        '''
        if self.debugLevel >= level:
            self.gl.log("[%s] %s" % (LOG_STRINGS[level], message))


    def run(self):
        '''
        Main method to run that looks in the md.log file for the corrupted elements.
        Fixes the ones it knows how to fix.
        '''
        # get the md.log file
        filename = ApplicationEnvironment.getInstallRoot() + '/md.log'
        self.log(INFO, 'opening ' + filename)
        logfile = open(filename)
        
        # grab the most recent corrupted elements from log file
        elements = []
        start_ii = 0
        end_ii = 0
        for ii, line in enumerate(logfile):
            if line.find('reason') >= 0:
                if ii - end_ii > 10:
                    start_ii = ii
                    elements = []
                end_ii = ii
                
                line = line[0:line.find('reason')]
                id = line[line.find('_'):].strip()
                element = self.project.getElementByID(id)
                if element not in elements:
                    elements.append(element)

        # lets try to fix the corruptions we know about (types)        
        try:
            SessionManager.getInstance().createSession("Fixing corrupted property elements")

            for element in elements:
                if element:
                    if isinstance(element, Property):
                        self.log(WARNING, "Corrupted property, tring to add type to %s" % (element.getQualifiedName()))
                        # lets add type to property since it's probably missing
                        if TYPE_MAP.has_key(element.getName()):
                            valueType = self.getValueType(TYPE_MAP[element.getName()])
                            element.setType(valueType)
                        else:
                            self.log(ERROR, "\tcould not find type")
                    self.corruptVr.addViolation(element, "Corrupted element found")

            SessionManager.getInstance().closeSession()
        except:
            SessionManager.getInstance().cancelSession()
            exceptionType, exceptionValue, exceptionTraceback = sys.exc_info()
            messages = traceback.format_exception(exceptionType, exceptionValue, exceptionTraceback)
            for message in messages:
                gl.log(message)
    
    def getValueType(self, valueType):
        '''
        Simple utility to get the value type provided the value type name
        '''
        return filter(lambda element: element.getName() == valueType, ModelHelper.getElementsOfType(self.project.getModel(), [DataType], False))[0]
                
    def hasErrors(self):
        if len(self.corruptVr.getViolations()) > 0:
            return True
        return False


# wrap the execution in try block so we can see any exceptions
try:            
    cea = CorruptedElementAnalysis()
    cea.run()
    
    scriptOutput = {}
    if cea.hasErrors():
        scriptOutput['DocGenValidationOutput'] = cea.vs
except:
    exceptionType, exceptionValue, exceptionTraceback = sys.exc_info()
    messages = traceback.format_exception(exceptionType, exceptionValue, exceptionTraceback)
    for message in messages:
        gl.log(message)