### This script is a utility to the other thermal scripts. It provides useful
### functions. It does not perform any analysis or assist with creating views.

### Author: David Coren, JPL


from com.nomagic.magicdraw.core import Application
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from com.nomagic.magicdraw.openapi.uml import SessionManager
from com.nomagic.magicdraw.openapi.uml import ModelElementsManager
from com.nomagic.uml2.ext.jmi.helpers import ModelHelper
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import Enumeration
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import AggregationKindEnum
from com.nomagic.uml2.ext.magicdraw.compositestructures.mdports import Port
from com.nomagic.magicdraw.teamwork.application import TeamworkUtils
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Lifeline
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import StateInvariant
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Interaction
from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import State
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import ElementValue
from com.nomagic.uml2.ext.magicdraw.commonbehaviors.mdsimpletime import DurationConstraint
from gov.nasa.jpl.mel import ModelLib

from javax.swing import JOptionPane
from javax.swing import JCheckBox
from java.lang import Object
from jarray import array
import sys
import traceback
import os

from gov.nasa.jpl.mbee.lib import Utils
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTable
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBText
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBColSpec
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTableEntry
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBParagraph
from gov.nasa.jpl.mbee import DocGenUtils
from gov.nasa.jpl.mel import PELTable as PELTablej
from gov.nasa.jpl.mgss.mbee.docgen.table import EditableTable
from gov.nasa.jpl.mgss.mbee.docgen.table import PropertyEnum

from EHM import PELUtils
reload(PELUtils)
from EHM import PELRollup as Rollup
reload(Rollup)

gl = Application.getInstance().getGUILog()
project = Application.getInstance().getProject()
ef = project.getElementsFactory()
mem = ModelElementsManager.getInstance()

def ownsPLPs(product):
    results = []
    ownedparts = []
    for ownedelement in product.getPart():
        if StereotypesHelper.getStereotype(project, "PartProperty") in StereotypesHelper.getStereotypes(ownedelement):
            ownedparts.append(ownedelement)
    for ownedpart in ownedparts:
        if ModelLib.isPLProduct(ownedpart.getType()) is True:
            PLP_type = ownedpart.getType()
            results.append(ownedpart)
    if len(results)>0:
        return True
    else:
        return False

def getOwnedPLPs(product): # collects leaf and assembly items
    results = []
    ownedparts = []
    for ownedelement in product.getPart():
        if StereotypesHelper.getStereotype(project, "PartProperty") in StereotypesHelper.getStereotypes(ownedelement):
            ownedparts.append(ownedelement)
    for ownedpart in ownedparts:
        if ModelLib.isPLProduct(ownedpart.getType()) is True:
            PLP_type = ownedpart.getType()
            results.append(ownedpart)
            results.extend(getOwnedPLPs(PLP_type))
    return results

def getOwnedLeafPLPs(product):
    results = []
    ownedparts = []
    for ownedelement in product.getPart():
        if StereotypesHelper.getStereotype(project, "PartProperty") in StereotypesHelper.getStereotypes(ownedelement):
            ownedparts.append(ownedelement)
    for ownedpart in ownedparts:
        if ModelLib.isPLProduct(ownedpart.getType()) is True:
            PLP_type = ownedpart.getType()
            if ownsPLPs(PLP_type) is False:
                results.append(ownedpart)
            if ownsPLPs(PLP_type) is True:
                results.extend(getOwnedLeafPLPs(PLP_type))
    return results

def getSuppliedProducts(workpackage):
    results = []
    suppliedparts = []
    authorizedWorkpackages = []
    for dependency in workpackage.getClientDependency():
        if ModelLib.isSupplies(dependency) is True:
            suppliedparts.append(dependency.getSupplier()[0])
            
    authorizedWorkpackages.extend(getAuthorizedWPs(workpackage))
            
    for wpkg2 in authorizedWorkpackages:
        suppliedparts.extend(getSuppliedProducts(wpkg2))
    return suppliedparts

def getAuthorizedWPs(workpackage):
    results = []
    authorizedWorkpackages = []
    for ownedElement in workpackage.getOwnedElement():
        if (ModelLib.isWorkPackage(ownedElement)) is True:
            authorizedWorkpackages.append(ownedElement)
            
    for dependency in workpackage.getClientDependency():
        if StereotypesHelper.getStereotype(project, "authorizes") in StereotypesHelper.getStereotypes(dependency):
            authorizedWorkpackages.append(dependency.getSupplier()[0])
    results = authorizedWorkpackages
    return results
