from com.nomagic.magicdraw.core import Application
from com.nomagic.magicdraw.openapi.uml import SessionManager
from com.nomagic.magicdraw.openapi.uml import ModelElementsManager
from com.nomagic.magicdraw.openapi.uml import PresentationElementsManager
from com.nomagic.magicdraw.uml.symbols.layout import *

from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import *
from com.nomagic.uml2.ext.magicdraw.classes.mddependencies import *
from com.nomagic.uml2.ext.magicdraw.classes.mdinterfaces import *
from com.nomagic.uml2.ext.magicdraw.actions.mdbasicactions import *
from com.nomagic.uml2.ext.magicdraw.activities.mdbasicactivities import *
from com.nomagic.uml2.ext.magicdraw.activities.mdintermediateactivities import *
from com.nomagic.uml2.ext.magicdraw.auxiliaryconstructs.mdinformationflows import *
from com.nomagic.uml2.ext.magicdraw.activities.mdfundamentalactivities import *
from com.nomagic.uml2.ext.magicdraw.interactions.mdfragments import *
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import *
from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import *
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper, ModelHelper
from com.nomagic.uml2.ext.magicdraw.compositestructures.mdports import *
from com.nomagic.magicdraw.automaton import AutomatonMacroAPI

from gov.nasa.jpl.mgss.mbee.docgen.validation import ValidationRule
from gov.nasa.jpl.mgss.mbee.docgen.validation import ValidationSuite
from gov.nasa.jpl.mgss.mbee.docgen.validation import ViolationSeverity
from gov.nasa.jpl.mbee.lib import Utils

import string
import random
import sys
import traceback

from gov.nasa.jpl.mbee.lib import Utils

import MDUtils._MDUtils as MDUtils
reload(MDUtils)
import SRUtils
reload(SRUtils)
import Validate_Structure
reload(Validate_Structure)

# listing of the power stereotypes
POWER_LOAD_PRODUCT_ST       = "Power Load Product"
POWER_LOAD_CHAR_ST          = "Power Load Characterization"
POWER_LOAD_BHVR_CHAR_ST     = "Power Load Behavior Characterization"

# Globals for including (rather than excluding for filters) and also checking derived types
include = True
derived = True

# load project information
project = Application.getInstance().getProject()
mainFrame = Application.getInstance().getMainFrame()
gl = Application.getInstance().getGUILog()
ef = project.getElementsFactory()
mem = ModelElementsManager.getInstance()
pem = PresentationElementsManager.getInstance()

def generalize(selected, options={'checkOnly':False}):
    gl.log("Generalizing: " + selected.getQualifiedName())
    checker = Validate_Structure.SRChecker(selected, options)
    checker.checkObsoleteRedefs()
    checker.removeObsoleteRedefs()
    checker.checkAttrs()
    checker.printErrors()
    
    if not editable(selected):
        gl.log(selected.getQualifiedName() + " is not editable!!! This branch will not be modified further")
        return
    
    if checker.hasErrors():
        checker.options['fixAll'] = True # suppress the dialog from popping up
        if checker.fixErrors():
            if checker.hasMissingProperties():
                populateMissing(checker.missingRedefErrs, selected, options)
        else:
            gl.log("There are errors I don't know how to fix, cannot continue")
    
    else:
        #if checker.hasExtraProperties():
        #    checker.printExtra()
        populateMissing(checker.missingRedefErrs, selected, options)
    
    if isinstance(selected, Class) or isinstance(selected, Interface):
        inheritedOperations = SRUtils.getInheritedOperations(selected)
        for o in inheritedOperations:
            if len(SRUtils.getRedefinedInChild(o, selected)) == 0:
                cloneOperation(selected, o, options)
    
    addConstraints(selected)
    if 'mapping' not in options:
        if 'redefineOnly' not in options or not options['redefineOnly']:
            checkPartProperties(checker.missingRedefErrs, checker.inherited, selected, options)
    
    parents = []
    for r in selected.get_directedRelationshipOfSource():
        if isinstance(r, Generalization):
            parents.append(ModelHelper.getSupplierElement(r))
    if len(parents) > 0:
        parent = parents[0]
        if ModelHelper.getComment(selected) == '' or ModelHelper.getComment(selected) is None:
            ModelHelper.setComment(selected, ModelHelper.getComment(parent))

def addConstraints(child):
    allInherited = filter(lambda e: isinstance(e, Constraint), child.getInheritedMember())
    for c in allInherited:
        consIns = ef.createConstraintInstance()
        consSpec = ef.createOpaqueExpressionInstance()
        consSpec.getBody().addAll(c.getSpecification().getBody())
        consIns.setSpecification(consSpec)
        consIns.getConstrainedElement().add(child)
        mem.addElement(consIns, child)
    
def checkPartProperties(missing, attrs, child, options):
    for cattr in child.getOwnedAttribute():
        #if attr in missing:
        #    continue
        if (StereotypesHelper.hasStereotypeOrDerived(cattr, SRUtils.partPropS) or cattr.getAggregation() == AggregationKindEnum.COMPOSITE) and cattr.getType() is not None:
            #c = SRUtils.getRedefinedInChild(attr, child)
            #if len(c) == 1:
                #ctype = c[0].getType()
                #ptype = attr.getType()
                #if ctype is not None and ptype is not None and isinstance(ptype, Class) and isinstance(ctype, Class):
                    #if ptype not in ctype.getSuperClass():
                        #MDUtils.createGeneralizationInstance(ptype, ctype)
                    #if ptype is not attr.getOwner() and ptype is not child and ptype not in SRUtils.getGeneralizationTree(child):
            if cattr.getType() is not child:
                generalize(cattr.getType(), options)
    
def populateMissing(attrs, child, options):
    if 'promptForParts' in options and options['promptForParts']:
        parts = filter(lambda e: StereotypesHelper.hasStereotypeOrDerived(e, SRUtils.partPropS) or (e.getAggregation() == AggregationKindEnum.COMPOSITE and e.getType() is not None and isinstance(e.getType(),Class)), attrs)
        notparts = filter(lambda e: e not in parts, attrs)
        selected = []
        if len(parts) > 0:
            selected = MDUtils.getUserCheckboxSelections("Choose parts", "Choose the ones you want under " + child.getName(), parts)
        notparts.extend(selected)
        newattrs = notparts
    else:
        newattrs = attrs
    for attribute in newattrs:
        name = SRUtils.getNameInChild(attribute.getName(), child)
        if name is not None and name.hasRedefinedProperty():
            r = []
            r.extend(name.getRedefinedProperty())
            r.append(attribute)
            if SRUtils.haveCommonRedefinition(r):
                name.getRedefinedProperty().add(attribute)
                continue
        #need to check if there's already an existing redefine for the case of multiple redefs
        cloneProp(child, attribute, options) #child doesn't already have it
 
 
def cloneOperation(child, o, options):
    newo = ef.createOperationInstance()
    newo.setOwner(child)
    newo.setName(o.getName())
    MDUtils.copyStereotypes(o, newo)
    newo.getRedefinedOperation().add(o)
    for p in o.getOwnedParameter():
        cloneParameter(newo, p, options)
        
def cloneParameter(childo, p, options):
    newp = ef.createParameterInstance()
    newp.setName(p.getName())
    if p.getType() is not None:
        if 'mapping' in options and p.getType() in options['mapping']:
            newp.setType(options['mapping'][p.getType()])
        else:
            newp.setType(p.getType())
    newp.setOwner(childo)
    copyMultiplicity(p, newp)
    newp.setDirection(p.getDirection())
    MDUtils.copyStereotypes(p, newp)
    
def copyMultiplicity(prop, newprop):
    newprop.setLowerValue(SRUtils.cloneValueSpec(prop.getLowerValue()))
    newprop.setUpperValue(SRUtils.cloneValueSpec(prop.getUpperValue()))
    newprop.setUnique(prop.isUnique())
    newprop.setOrdered(prop.isOrdered())
    
def cloneProp(child, prop, options):
    mul = SRUtils.getMultiplicity(prop)
    if 'expandMultiplicity' in options:
        for i in range(mul):
            clonePropOnce(child, prop, options, i)
    else:
        clonePropOnce(child, prop, options, 0)
        

def clonePropOnce(child, prop, options, i):
    newProp = None
    if prop.getType() is not None and isinstance(prop.getType(), Enumeration):
        newProp = cloneValueProp(child, prop, options)
    elif StereotypesHelper.hasStereotypeOrDerived(prop, SRUtils.consPropS):
        newProp = cloneConstraintProp(child, prop, options)
    elif StereotypesHelper.hasStereotypeOrDerived(prop, SRUtils.valuePropS):
        newProp = cloneValueProp(child, prop, options)
    elif StereotypesHelper.hasStereotypeOrDerived(prop, SRUtils.partPropS):
        newProp = clonePartProp(child, prop, options)
    elif StereotypesHelper.hasStereotypeOrDerived(prop, SRUtils.sharedPropS):
        newProp = cloneSharedProp(child, prop, options)
    elif isinstance(prop, Port):
        newProp = clonePortProp(child, prop, options)
    elif StereotypesHelper.hasStereotypeOrDerived(prop, SRUtils.refPropS):
        newProp = cloneSharedProp(child, prop, options)
    else:
        newProp = cloneUMLProp(child, prop, options)
    if newProp is not None:
        mem.addElement(newProp, child)
        MDUtils.copyStereotypes(prop, newProp)
        MDUtils.setRedefine(prop, newProp)
        if i == 0:
            newProp.setName(prop.getName())
        else:
            newProp.setName(prop.getName() + str(i+1))
        newProp.setAggregation(prop.getAggregation())
        if 'expandMultiplicity' not in options:
            copyMultiplicity(prop, newProp)
        mem.addElement(newProp, child)
    
def cloneValueProp(child, prop, options):
    newType = prop.getType()
    if "mapping" in options and newType in options['mapping']:
        newType = options['mapping'][newType]
        
    if prop.getAssociation() is not None and newType is not None:
        newProp = makeAssociation(child, newType, prop, prop.getAssociation())
    else:
        newProp = ef.createPropertyInstance()
    #newProp = ef.createPropertyInstance()

    newProp.setType(newType)
    default = prop.getDefaultValue()
    if default is not None:
        newProp.setDefaultValue(SRUtils.cloneValueSpec(default))
    return newProp
    
def clonePartProp(child, prop, options):
    #if 'promptForParts' in options and options['promptForParts']:
    #    choice = JOptionPane.showConfirmDialog(None, "Make copy for " + prop.getName() + " under " + child.getName() + "?" , "Propagate part property?", JOptionPane.YES_NO_OPTION)
    #    if choice == JOptionPane.NO_OPTION:
    #        return None
                       
    newProp = None
    newType = None
    #what if type is already made and this is a new instance prop for same type??
    ptype = prop.getType()
    if ptype is prop.getOwner():
        gl.log("[WARNING]: self composition loop detected, only one level will be made: " + prop.getQualifiedName())
        return None
    if ptype is child or (ptype is not None and prop.getOwner() in SRUtils.getGeneralizationTree(ptype)):
        gl.log("[WARNING]: self composition and specialization loop detected, will not follow through: " + prop.getQualifiedName())
        return None
    if ptype is not None:
        if "mapping" in options and ptype in options['mapping']:
            newType = options['mapping'][ptype]
        if 'redefineOnly' in options and options['redefineOnly']:
            newType = ptype
        elif newType is None:
            if isinstance(ptype, Activity):
                newType = ef.createActivityInstance()
            elif isinstance(ptype, Enumeration):
                newType = ef.createEnumerationInstance()
            elif isinstance(ptype, Interface):
                newType = ef.createInterfaceInstance()
            elif isinstance(ptype, StateMachine):
                newType = ef.createStateMachineInstance()
            elif isinstance(ptype, Interaction):
                newType = ef.createInteractionInstance()
            elif isinstance(ptype, OpaqueBehavior):
                newType = ef.createOpaqueBehaviorInstance()
            else:
                newType = ef.createClassInstance()
            if 'useTypeName' in options and options['useTypeName']:
                newType.setName(ptype.getName())
            else:
                newType.setName(prop.getName())
            #if ptype.hasOwnedComment():
            #    ModelHelper.setComment(newType, ModelHelper.getComment(ptype))
            newType.setOwner(child)
            MDUtils.copyStereotypes(ptype, newType)
            MDUtils.createGeneralizationInstance(ptype, newType)
        #if 'mapping' in options: #breaks pakcage clone because it's iterating through mapping
        #    options['mapping'][ptype] = newType
            #generalize(newType, options) this gets done at the end in check part properties
    
    if prop.getAssociation() is not None:
        newProp = makeAssociation(child, newType, prop, prop.getAssociation())
    else:
        newProp = ef.createPropertyInstance()
    if newType is not None:
        newProp.setType(newType)
    default = prop.getDefaultValue()
    if default is not None:
        newProp.setDefaultValue(SRUtils.cloneValueSpec(default))
    return newProp

def cloneSharedProp(child, prop, options):
    newProp = None
    #if prop.getAssociation() is not None:
    #    newProp = self.makeAssociation(child, prop.getType(), prop)
    #else:
    if "mapping" in options and prop.getType() in options['mapping']:
        if prop.getAssociation() is not None:
            newProp = makeAssociation(child, options['mapping'][prop.getType()], prop, prop.getAssociation())
        else:
            newProp = ef.createPropertyInstance()
        newProp.setType(options['mapping'][prop.getType()])
    else:
        if prop.getAssociation() is not None:
            newProp = makeAssociation(child, prop.getType(), prop, prop.getAssociation())
        else:
            newProp = ef.createPropertyInstance()
        newProp.setType(prop.getType())
    return newProp
    
def clonePortProp(child, prop, options):
    newProp = ef.createPortInstance()
    if 'mapping' in options and prop.getType() in options['mapping']:
        newProp.setType(options['mapping'][prop.getType()])
    else:
        newProp.setType(prop.getType())
   
    if StereotypesHelper.hasStereotypeOrDerived(prop, SRUtils.flowPortS):
        StereotypesHelper.addStereotype(newProp, SRUtils.flowPortS)
        StereotypesHelper.setStereotypePropertyValue(newProp, SRUtils.flowPortS, 'direction', StereotypesHelper.getStereotypePropertyFirst(prop, SRUtils.flowPortS, 'direction'))
        StereotypesHelper.setStereotypePropertyValue(newProp, SRUtils.flowPortS, 'isAtomic', StereotypesHelper.getStereotypePropertyFirst(prop, SRUtils.flowPortS, 'isAtomic'))
    return newProp
    
def cloneUMLProp(child, prop, options): # this is if the property is not a sysml property
    #this needs to be checked, how to check if attr is uml value?
    if prop.getType() is not None and isinstance(prop.getType(), Enumeration):
        return cloneValueProp(child, prop, options)
    if prop.getAssociation() is not None or prop.getAggregation() != AggregationKindEnum.NONE:
        a = prop.getAggregation()
        if a == AggregationKindEnum.SHARED:
            return cloneSharedProp(child, prop, options)
        elif a == AggregationKindEnum.COMPOSITE:
            return clonePartProp(child, prop, options)
        else:
            return None #???
    else:
        return cloneValueProp(child, prop, options)
            
def cloneConstraintProp(child, prop, options): #this is for regular constraints as well as tree constraints, wires the new one according to the parent one, tree constraints will be redone later, but the result of the tree constraint will be connected here
    newProp = None
    con = prop.getType()
    if con is None:
        return ef.createPropertyInstance()
    if 'mapping' in options and con in options['mapping']:
        if prop.getAssociation() is not None:
            newProp = makeAssociation(child, options['mapping'][con], prop, prop.getAssociation())
        else:
            newProp = ef.createPropertyInstance()
        newProp.setType(options['mapping'][con])
    else:
        newProp = ef.createPropertyInstance()
        newProp.setType(con)
    return newProp
            
def makeAssociation(owner, oppowner, refprop, refasso): 
    asso = None
    if isinstance(refasso, AssociationClass):
        asso = ef.createAssociationClassInstance()
    else:
        asso = ef.createAssociationInstance()
    newProp = asso.getMemberEnd().get(0)
    newProp2 = asso.getMemberEnd().get(1)
    newProp2.setType(owner)
    #should also set aggregation or redefine?
    if refprop.getOpposite() is not None:
        MDUtils.copyStereotypes(refprop.getOpposite(), newProp2)
    if refprop.getOpposite()is not None and refprop.getOpposite().isNavigable() and oppowner is not None:
        newProp2.setName(refprop.getOpposite().getName())
        mem.addElement(newProp2, oppowner)
    else:
        mem.addElement(newProp2, asso)
    mem.addElement(asso, owner.getOwner())
    MDUtils.createGeneralizationInstance(refasso, asso)
    MDUtils.copyStereotypes(refasso, asso)
    if isinstance(asso, AssociationClass):
        asso.setName(refasso.getName())
        generalize(asso)
    return newProp
        

def checkParentTree(select):
    general = select.getGeneral()
    for g in select.getGeneral():
        checker = Validate_Structure.SRChecker(g, {'checkOnly':True})
        checker.checkAttrs()
        if checker.hasErrors() or checker.partHasErr:
            checker.printErrors()
            return False
    return True

def editable(e):
    if not e.isEditable():
        return False
    for o in e.getOwnedElement():
        if not editable(o):
            return False
    return True

def run(mode, selected):
    #selected = None
    #if mode == 'b':
        #selected = Application.getInstance().getMainFrame().getBrowser().getActiveTree().getSelectedNode().getUserObject()
    #if mode == 'd':
        #selected = Application.getInstance().getProject().getActiveDiagram().getSelected().get(0).getElement()
    if not isinstance(selected, Class) and not isinstance(selected, Interface):
        gl.log("You must select a block/class!!!")
        return
    if not editable(selected):
        gl.log("Selected is not editable all the way!!!")
        return
    options = {'checkOnly':False}
    options['promptForParts'] = True
    options['useTypeName'] = True
    generalize(selected, options)


class PowerLoadCharacterizationValidation:
    '''
    Validation class for making sure the power load characterization and scenarios is accurate
    @param isUserScript:    TRUE if run as user script from validation menu, FALSE if run as macro
    @param fixMode:         None, All, or Selected does verification or fixing
    @param root:            The root object to validate
    '''
    def __init__(self, isUserScript, fixMode, root):
        self.isUserScript = isUserScript
        self.fixMode = fixMode
        self.root = root
        # lets create the validation rules
        self.vs = ValidationSuite("Power Load Characterization Validation for %s" % (root.getName()))
        self.missingScenarioVr = ValidationRule("Missing scenario", "Missing scenario", ViolationSeverity.ERROR)
        self.missingLifelineVr = ValidationRule("Missing lifeline", "Scenario is missing lifeline", ViolationSeverity.ERROR)
        self.writeErrorVr = ValidationRule("Write error due to read-only mode", "Read only write error", ViolationSeverity.WARNING)
        self.vs.addValidationRule(self.missingScenarioVr)
        self.vs.addValidationRule(self.missingLifelineVr)
        self.vs.addValidationRule(self.writeErrorVr)
        
        self.newSmi = []
        self.wps = []
        self.redefs = set()
        
        
    def hasChildPowerLoadProduct(self, product):
        '''
        Determines whether the specified power load product has any children power load products.
        @param product:    Power load product to check for children
        @return:           True if there are children of type power load product, otherwise False
        '''
        children = product.getOwnedElement()
        for child in children:
            if not hasattr(child, "getType"):
                continue
            else:
                childType = child.getType()
                if childType:
                    if StereotypesHelper.hasStereotypeOrDerived(childType, POWER_LOAD_PRODUCT_ST):
                        return True
        return False
    
    def getPowerProducts(self, children):
        '''
        Returns a list of all leaf power load product parts based off the supplied MD elements
        @param children:    List of MD elements to check for power load product parts
        @return:            List of all leaf power load product parts
        '''
        # this is the list of all leaf power products
        partList = []

        # get all children with type stereotyped as <<Power Load Product>>
        for part in filter(lambda x: hasattr(x, "getType"), children):
            if part in self.redefs:
#                gl.log("REDEFINITION found for [%s]" % (part.getQualifiedName()))
                continue
            if isinstance(part, Property):
#                gl.log("found part: %s" % (part.getQualifiedName()))
                if part.getName() == "INMS":
                    gl.log("\nFOUND INMS part with multiplicity [%d, %d]\n" % (part.getLower(), part.getUpper()))
                redef = part.getRedefinedElement()
                if len(redef) > 0:
#                    gl.log("redefines: [%s] => [%s]" % (part.getQualifiedName(), redef[0].getQualifiedName()))
                    self.redefs.add(redef[0])
                if part.getLower() == 0 and part.getUpper() == 0:
                    continue
            partType = part.getType()
#            self.findWorkPackage(partType)                
            if partType:
                if StereotypesHelper.hasStereotypeOrDerived(partType, POWER_LOAD_PRODUCT_ST):
                    if not self.hasChildPowerLoadProduct(partType):
                        if part not in partList:
                            partList.append(part)
                    else:
                        # if children, add children parts (want flat list so extend)
                        partList.extend(self.getPowerProducts(partType.getOwnedElement()))
        
        return partList


    def getPowerLoadCharacterizations(self, plbc):
        '''
        Given a Power Load Behavior Characterization, gets all the Power Load Characterizations for
        which a sequence should exist
        @param plbc:    Power Load Behavior Characterization to look for PLCs for
        @return:        List of PLCs for the provided PLBC
        '''
        children = plbc.getOwnedElement()
        return Utils.filterElementsByStereotypeString(children, POWER_LOAD_CHAR_ST, include, derived)
    
    
    def findMissingScenarios(self, parent, plcs):
        '''
        Finds the missing sequences in parent.
        @param parent:    Parent to look for sequences in
        @param plcs:      List of scenario names that should exist (e.g., PLCs in the PLBC)
        @return:          List of the missing scenarios
        '''
        children = parent.getOwnedElement()
        scenarios = filter(lambda x: isinstance(x, Interaction), children)
        scenarios = map(lambda x: x.getName(), scenarios)
        
        missingScenarios = []
        for plc in plcs:
            if plc.getName() not in scenarios:
                missingScenarios.append(plc)
        
        return missingScenarios
    
    def checkAndFixInteractionUses(self, scenario, parentScenarios, fix=False):
        '''
        Method for a given scenario adds the parentScenarios as interaction uses
        @param scenario:            Scenario to add parent scenarios to
        @param parentScenarios:     List of parent scenarios to be added
        @param fix:                 True if fixes should be made, False otherwise
        '''
        # lets add the references onto the diagrams for all the parents
        interactionUses = filter(lambda x: isinstance(x, InteractionUse), scenario.getMember())
        references = map(lambda x: x.getRefersTo(), interactionUses)
        
        for ps in parentScenarios:
            found = False
            for iu in  interactionUses:
                if ps == iu.getRefersTo():
                    found = True
                    break
            if found:
                gl.log("[INFO] Scenario %s already contains reference to %s" % (scenario.getName(), ps.getName()))
                if fix:
                    for diagram in scenario.getOwnedDiagram():
                        dpel = project.getDiagram(diagram)
                        element = dpel.findPresentationElement(iu, None)
                        if iu.getName() != ps.getName():
                            iu.setName(ps.getName())
                        if not element:
                            pem.createShapeElement(iu, project.getDiagram(diagram))
            else:
                if not fix:
                    gl.log("[WARNING] Scenario %s does not contain reference to parent %s" % (scenario.getName(), ps.getName()))
                else:
                    gl.log("[WARNING] Scenario %s does not contain reference to parent %s: Adding missing reference" % (scenario.getName(), ps.getName()))
                    newInteractionUse = ef.createInteractionUseInstance()
                    newInteractionUse.setRefersTo(ps)
                    newInteractionUse.setOwner(scenario)
                    newInteractionUse.setName(ps.getName())
                    for diagram in scenario.getOwnedDiagram():
                        pem.createShapeElement(newInteractionUse, project.getDiagram(diagram))


    def checkAndFixScenarios(self, parent, pwrParts, plcs, fix=False):
        '''
        Checks that the scenarios have all the necessary lifelines
        @param parent:      Parent to look for scenarios in
        @param pwrParts:    List of parts that are expected in a scenario
        @param plcs:        Only add to scenarios that have power load characterizations
        @return:            TRUE if all scenarios have all part lifelines, FALSE otherwise
        '''
        status = True
        
        children = filter(lambda x: hasattr(x, "getName"), parent.getOwnedElement())
        scenarios = filter(lambda x: isinstance(x, Interaction), children)        
        
        plcsNames = map(lambda x: x.getName(), plcs)
        
        for scenario in scenarios:
            if scenario.getName() not in plcsNames:
                continue
            # collect lifelines on interaction diagram
            lifelines = filter(lambda x: isinstance(x, Lifeline), scenario.getMember())
            lifelineTypes = map(lambda x: x.getRepresents(), lifelines)
            
            # lets find the parents for the scenarios and the parts in there
            parentScenarios = Utils.collectDirectedRelatedElementsByRelationshipJavaClass(scenario, Generalization, 1, 0)
            parentScenarios = filter(lambda x: isinstance(x, Interaction), parentScenarios)
            parentLifelines = []
            for ps in parentScenarios:
                parentLifelines.extend(filter(lambda x: isinstance(x, Lifeline), ps.getMember()))
            parentLifelineTypes = map(lambda x: x.getRepresents(), parentLifelines)

            self.checkAndFixInteractionUses(scenario, parentScenarios, fix)

            for pwrPart in pwrParts:
                # TODO: need to remove extraneous lifelines
                if pwrPart in parentLifelineTypes:
                    if pwrPart in lifelineTypes:
                        if not fix:
                            gl.log("[WARNING] For %s found %s that is in parent scenario" % (scenario.getName(), pwrPart.getName()))
                        else:
                            gl.log("[WARNING] For %s removing %s that is in parent scenario" % (scenario.getName(), pwrPart.getName()))
                            for index, part in enumerate(lifelineTypes):
                                if part == pwrPart:
                                    for diagram in scenario.getOwnedDiagram():
                                        dpel = project.getDiagram(diagram)
                                        element = dpel.findPresentationElement(lifelines[index], None)
                                        if element:
                                            pem.deletePresentationElement(element)
                                    break
                    continue
                if pwrPart not in lifelineTypes:
                    status = False
                    if not fix:
                        self.missingLifelineVr.addViolation(pwrPart, "Did not find %s in %s" % (pwrPart.getName(), scenario.getName()))
                        gl.log("[WARNING] Did not find %s in %s" % (pwrPart.getName(), scenario.getName()))
                    else:
                        gl.log("[WARNING] Adding missing %s to %s" % (pwrPart.getName(), scenario.getName()))
                        newLifeline = ef.createLifelineInstance()
                        newLifeline.setRepresents(pwrPart)
                        newLifeline.setInteraction(scenario)
                        # add missing lifeline into all owned diagrams
                        for diagram in scenario.getOwnedDiagram():
                            pem.createShapeElement(newLifeline, project.getDiagram(diagram))
        
        return scenarios
    
    
    def addScenarios(self, parent, plcs, pwrParts):
        if ignoreWriteErrors:
            try:
                self.internalAddScenarios(parent, plcs, pwrParts)
            except:
                gl.log("[WARNING] Trying to write to read-only PLCS %s" % (plcs.getQualifiedName()))
                self.writeErrorVr.addViolation(plp, "Trying to write to read-only %s" % (plcs.getQualifiedName()))
        else:
            self.internalAddScenarios(parent, plcs, pwrParts)
     
    def internalAddScenarios(self, parent, plcs, pwrParts):
        '''
        Adds missing scenarios to the parent.
        @param parent:      Parent PLC to add scenarios to
        @param plcs:        List of PLCS names to create scenarios for
        @param pwrParts:    List of power load products parts to create lifelines for 
        '''
        missingScenarios = self.findMissingScenarios(parent, plcs)
        
        for scenario in missingScenarios:
            scenarioName = scenario.getName()
            gl.log("adding scenario %s" % (scenarioName))
            # create the interaction
            interaction = ef.createInteractionInstance()
            interaction.setName(scenarioName)
            interaction.setOwner(parent)
            StereotypesHelper.addStereotypeByString(interaction, "Scenario")
    
            # create diagram
            diagram = mem.createDiagram("SysML Sequence Diagram", interaction)
            diagram.setName(scenarioName)
            diagram.setOwner(interaction)
            StereotypesHelper.addStereotypeByString(diagram, "DiagramInfo")
            if StereotypesHelper.getStereotype(project, "view") != None:
                StereotypesHelper.addStereotypeByString(diagram, "view") #formerly "DGView"
            else:
                StereotypesHelper.addStereotypeByString(diagram, "DGView") #for backwards compatibility
            diagramPresentationElement = project.getDiagram(diagram)
    
            # create all the lifelines per the pwr parts
            for pwrPart in pwrParts:
                gl.log("  adding lifeline %s to %s" % (pwrPart.getName(), interaction.getName()))
                lifeline = ef.createLifelineInstance()
                lifeline.setRepresents(pwrPart)
                lifeline.setInteraction(interaction)
                pem.createShapeElement(lifeline, diagramPresentationElement)
                    
            # create the scenario property and corresponding lifeline
            property = ef.createPropertyInstance()
            property.setName(scenarioName)
            property.setOwner(interaction)
            property.setType(scenario)
            lifeline = ef.createLifelineInstance()
            lifeline.setRepresents(property)
            lifeline.setInteraction(interaction)
            StereotypesHelper.addStereotypeByString(lifeline, "Mode Lifeline")
            pem.createShapeElement(lifeline, diagramPresentationElement)

    def addModesToPowerLoadProduct(self, plp, modes=["On", "Off", "Standby"]):
        '''
        Wrapper around the internal add modes call - this lets us ignore write errors if
        necessary
        '''
        if ignoreWriteErrors:
            try:
                self.internalAddModesToPowerLoadProduct(plp, modes)
            except:
                self.writeErrorVr.addViolation(plp, "Trying to write to read-only PLP %s  with modes [%s]" % (plp.getQualifiedName(), modes))
#                gl.log("\n========\nSkipping: No write permissions to %s\n=========\n" % (plp.getName()))
        else:
            self.internalAddModesToPowerLoadProduct(plp, modes)
    
    
    def internalAddModesToPowerLoadProduct(self, plp, modes=["On", "Off", "Standby"]):
        '''
        Adds the specified modes to the Power Load Behavior Characterization. Also validates that
        every mode has the three power characteristics
        @param plp:          Power load product part or work package to add modes to
        @param modes:        Name of the modes to add to the PLBC
        '''
        # get state machine in plp (plp can be a part or a work package
        if hasattr(plp, "getType"):
            oes = Utils.collectOwnedElements(plp.getType(), 1)
        else:
            oes = Utils.collectOwnedElements(plp, 1)
        oe = []
        for element in oes:
            if StereotypesHelper.hasStereotypeOrDerived(element, POWER_LOAD_BHVR_CHAR_ST):
                oe.append(element)
            elif hasattr(element, "getName") and element.getName() == POWER_LOAD_BHVR_CHAR_ST:
                oe.append(element)
        
        if len(oe) > 1:
            gl.log("More than one power load behavior characterization under %s, using first" % (plp.getName()))
            sm = oe[0]
        elif len(oe) == 0:
            gl.log("No power load behavior characterization under %s" % (plp.getName()))
            if isinstance(plp, Property):
                return
            
            # lets create the state machine
            sm =  ef.createStateMachineInstance()
            sm.setOwner(plp)
            sm.setName(POWER_LOAD_BHVR_CHAR_ST)
            StereotypesHelper.addStereotypeByString(sm, POWER_LOAD_BHVR_CHAR_ST)
        else:
            gl.log("Found state machine under %s" % (plp.getName()))
            sm = oe[0]
        
        p = sm.getOwner()
        children = Utils.collectOwnedElements(p, True)
        plcsunderplp = Utils.filterElementsByStereotypeString(children, POWER_LOAD_CHAR_ST, True, True)
        if len(plcsunderplp) == 0:
            gl.log("Did not find power load characterization under power load product: %s" % (plp.getName()))
            return
        #TODO: really need to check for the PLC under the PLP
        plcunderplp = plcsunderplp[0]
        
        # Check if diagram already exists
        diagram = None
        for child in sm.getOwnedElement():
            if isinstance(child, Diagram):
                diagram = child
                break
        if not diagram:
            diagram = mem.createDiagram("SysML State Machine Diagram", sm)
            diagram.setName(sm.getName())
            diagram.setOwner(sm)
        diagramPel = project.getDiagram(diagram)
        
        region = Utils.collectOwnedElements(sm,1)
        region = Utils.filterElementsByJavaClass(region, Region, True)[0]

        # add all the specified modes and validate that they have the write properties
        changed = False        
        for mode in modes:
            gl.log("Creating state machine %s: for %s" % (mode, sm.getName()))
            
            # check that the state machines don't already exist
            smi = None
            for child in sm.getOwnedElement():
                if isinstance(child, StateMachine) and child.getName().lower() == mode.lower():
                    smi = child
                    gl.log("State machine %s already exists" % (mode))
                    if child.getName() != mode:
                        gl.log("Case for %s doesn't match, fixing to %s" % (child.getName(), mode))
                        child.setName(mode)
            
            # if state machine doesnt exist create it and add elements
            if not smi:
                smi = ef.createStateMachineInstance()
                smi.setName(mode)
                genSmi = ef.createGeneralizationInstance()
                genSmi.setGeneral(plcunderplp)
                genSmi.setSpecific(smi)
                StereotypesHelper.addStereotypeByString(smi, POWER_LOAD_CHAR_ST)
                mem.addElement(smi, sm)
                mem.addElement(genSmi, smi)
                stateSmi = ef.createStateInstance()
                stateSmi.setName(mode)
                stateSmi.setSubmachine(smi)
                mem.addElement(stateSmi, region)
                pem.createShapeElement(stateSmi, diagramPel)
                self.newSmi.append(smi)
                changed = True
                
            # check smi to get properties and see if they have all the three Power Load Product properties
            self.addPropertyToStateMachine(smi, "contingency", valueType="Real", value = 0.3)
            self.addPropertyToStateMachine(smi, "steady-state power CBE", valueType="W", value = None)
            self.addPropertyToStateMachine(smi, "steady-state power MEV", valueType="W", value = None)
       
        if changed:
            diagramPel.open()
            diagramPel.layout(True, HierarchicDiagramLayouter())
            diagramPel.close()


    def addPropertyToStateMachine(self, smi, propertyName, valueType="Real", value=None):
        '''
        Adds the specified property to a state machine instance
        @param smi:            State machine instance to add property to
        @param propertyName:   Name of the property to be added
        @param valueType:      String of the property's value type (to be looked up)
        @param value:          Value to be injected into the property
        '''
        # find the specified property if it exists
        propToFind = None
        properties = smi.getOwnedElement()
        for property in filter(lambda x: isinstance(x, Property), properties):
            if property.getName() == propertyName:
                propToFind = property
                break
        
        # if property doesn't exist, create it
        if not propToFind:
            propToFind = ef.createPropertyInstance()
            propToFind.setName(propertyName)
            propToFind.setOwner(smi)
            StereotypesHelper.addStereotypeByString(propToFind, "ValueProperty")

            # TODO: this only works for Real types (need to fix)
            if value:
                lri = ef.createLiteralRealInstance()
                lri.setValue(value)
                propToFind.setDefaultValue(lri)            

        # Reinforce all the property types
        # TODO: This is a kludge to find the DataType
        valueType = filter(lambda element: element.getName() == valueType, ModelHelper.getElementsOfType(project.getModel(), [DataType], False))[0]
        propToFind.setType(valueType)
                

    def findWorkPackage(self, product):
        '''
        Simple method for finding a Work Package that supplies a product. All WPs are stored in global array
        @param product:    Product to find work package for
        @return:           Returns work package found for the specified product
        '''
        if product:
            target = None
            for dr in product.get_directedRelationshipOfTarget():
                if StereotypesHelper.hasStereotypeOrDerived(dr, "supplies"):
                    target = ModelHelper.getClientElement(dr)
                    if StereotypesHelper.hasStereotypeOrDerived(target, "Work Package"):
                        if target not in self.wps:
                            self.wps.append(target)
                            gl.log("Found work package %s for product %s" % (target.getQualifiedName(), product.getName()))
                            break
        
        return target


    def generateWorkPackageTree(self, wp):
        if wp:
            target = None
            for dr in wp.getClientDependency():
                if StereotypesHelper.hasStereotypeOrDerived(dr, "authorizes"):
                    target = ModelHelper.getSupplierElement(dr)
#                    gl.log("found authorize relationship to [%s]" % (target.getName()))
                    if StereotypesHelper.hasStereotypeOrDerived(target, "Work Package"):
                        if target not in self.wps:
                            self.wps.append(target)
                            self.generateWorkPackageTree(target)


    def addPowerLoadBehaviorCharacterization(self, wp, plcs):
        '''
        Helper to add the Power Load Characterizations to PLBC in WP
        @param wp:        Work package to update the PLBC for
        @param plcs:      Power Load Characterizations to be added into the WP
        '''
        modes = map(lambda x: x.getName(), plcs)
        gl.log("adding %s to %s of type(%s)" % (modes, wp.getName(), type(wp)) )
        self.addModesToPowerLoadProduct(wp, modes)


    def findPowerLoadBehaviorCharacterization(self, parent, children):
        '''
        For a set of children, find the PLBC
        @param parent:          Parent of the children being searched, just for logging
        @param children:        Children in which to look for plbc
        @return:                The PLBC if found, None otherwise
        '''
        plbc = None
        
        for child in filter(lambda x: hasattr(x, "getName"), children):
            # TODO: need to figure out why stereotypes checking isn't working
            if POWER_LOAD_BHVR_CHAR_ST in map(lambda x: x.getName(), StereotypesHelper.getStereotypes(child)):        
                plbc = child
                if child.getName() != POWER_LOAD_BHVR_CHAR_ST:
                    gl.log("[WARNING] %s <<%s>> not named properly => %s" % (parent.getName(), POWER_LOAD_BHVR_CHAR_ST, child.getName()))
                break
        
        return plbc
    
    
    def specializePlcs(self, wp):
        '''
        Make sure that the PLCs in the PLBCs of the WP specialize the WP's PLC.
        @param wp:    Work package to specialize PLCs for
        '''
        # find the PLCs of the WP
        children = filter(lambda x: hasattr(x, "getName"), wp.getOwnedElement())
        plcs = filter(lambda x: x.getName() == POWER_LOAD_CHAR_ST, children)
        if len(plcs) <= 0:
            gl.log("[WARNING] WP: [%s] does not have a %s" % (wp.getName(), POWER_LOAD_CHAR_ST))
            return
        plc = plcs[0]
        
        # get the PLBC, then the PLCs under the PLBC
        plbc = self.findPowerLoadBehaviorCharacterization(wp, children)
        plcsunderplbc = filter(lambda x: StereotypesHelper.hasStereotypeOrDerived(x, POWER_LOAD_CHAR_ST), plbc.getOwnedElement())

        # add generalization if it's missing        
        for plcunderplbc in plcsunderplbc:
            generalizations = MDUtils.collectGeneralizations(plcunderplbc, False)
            if hasattr(plc, "getType"):
                if plc.getType() not in generalizations:
                    MDUtils.createGeneralizationInstance(plc.getType(), plcunderplbc)
    
    
    def fixAll(self, pwrParts, plcs):
        if self.fixMode == "FixSelected" or self.fixMode == "FixAll":
            for plp in pwrParts:
                self.addModesToPowerLoadProduct(plp)
            self.addScenarios(root, plcs, pwrParts)
            self.checkAndFixScenarios(root, pwrParts, plcs, fix=True)
            self.addModesToPowerLoadProduct(self.root, map(lambda x: x.getName(), plcs))
            for wp in self.wps:
                self.addPowerLoadBehaviorCharacterization(wp, plcs)
                self.specializePlcs(wp)
            for smi in self.newSmi:
                run('b', smi)
            self.logWriteErrors()

                    
    def run(self):
        '''
        This is the main execution path for the validation that finds all the leaf parts
        and all the scenarios that are required
        '''
       
        # make sure that a <<Power Load Product>> was specified
        if not StereotypesHelper.hasStereotypeOrDerived(root, POWER_LOAD_PRODUCT_ST):
            gl.log("[ERROR] Select a <<Power Load Product>> in the containment tree")
            return -1
        else:
            gl.log("User selected <<Power Load Product>>: %s" % (self.root.getName()))

        # get the initial work package
        wp = self.findWorkPackage(self.root)
        
        # lets build authorizes tree
        self.generateWorkPackageTree(wp)
                
        # get children parts first (this lets us build up the redefinition map to skip in the inherited)
        # lets get all the leaf parts of owned elements
        children = Utils.collectOwnedElements(self.root, 1)
        pwrParts = self.getPowerProducts(children)

        # lets get parts of the base classifiers
        pwrParts.extend(self.getPowerProducts(self.root.getInheritedMember()))

        # get the power load behavior characterizations for root and any inherited
        plbc = self.findPowerLoadBehaviorCharacterization(self.root, children)
        iplbc = self.findPowerLoadBehaviorCharacterization(self.root, self.root.getInheritedMember())

        # get the power load characterizations (which are the scenarios that should exist)    
        plcs = self.getPowerLoadCharacterizations(plbc)
        if iplbc:
            # lets check all the plcs in iplbc and see if any of the plcs redefine them
            plcs.addAll(self.getPowerLoadCharacterizations(iplbc))
        for plc in plcs:
            gl.log("found plc: %s" % (plc.getName()))
        
        missingScenarios = map(lambda x: x.getName(), self.findMissingScenarios(root, plcs))
        for scenario in missingScenarios:
            self.missingScenarioVr.addViolation(self.root, "Missing scenario: %s" % (scenario))
            gl.log("Missing scenario: [%s]" % (scenario))
        
        # do validation first
        if self.fixMode == "FixNone":
            self.checkAndFixScenarios(root, pwrParts, plcs, fix=False)
        
        # create session if run as macro (user scripts have a session managed)
        if self.isUserScript:
            if self.fixMode == "FixSelected" or self.fixMode == "FixAll":
                self.fixAll(pwrParts, plcs)
        else:
            try:
                SessionManager.getInstance().createSession("Fixing power scenarios")
                self.fixAll(pwrParts, plcs)
                SessionManager.getInstance().closeSession()
            except:
                SessionManager.getInstance().cancelSession()
                exceptionType, exceptionValue, exceptionTraceback = sys.exc_info()
                messages = traceback.format_exception(exceptionType, exceptionValue, exceptionTraceback)
                for message in messages:
                    gl.log(message)
        
        return 0
    
    def hasErrors(self):
        if len(self.missingLifelineVr.getViolations()) > 0 or len(self.missingScenarioVr.getViolations()) > 0 or len(self.writeErrorVr.getViolations())>0:
            return True
        return False
    
    def logWriteErrors(self):
        for violation in self.writeErrorVr.getViolations():
            gl.log("[WARNING] %s" % (violation.getComment()))

'''
This script can be run either as a macro or a user script
'''
isUserScript = True

# check to see if this is run as Validation User Script
try:
    inputs = scriptInput['DocGenTargets']
    if len(inputs) > 1:
        gl.log("Only accepts one <<Power Load Product>>")
        exit()
    root = inputs[0]
    fixMode = scriptInput["FixMode"]
except NameError:
    isUserScript = False

# Global for ignoring read errors (e.g., write when only in read only)
ignoreWriteErrors = True

# if run as macro, ask user to select
if not isUserScript:
    # get the option to do check or fix
    if Utils.getUserYesNoAnswer("Select YES to check rules or NO to enforce rules"):
        fixMode = "FixNone"
    else:
        fixMode = "FixSelected"
    
    # get option to ignore editable errors
    if Utils.getUserYesNoAnswer("Throw exception when trying to write on read-only elements?"):
        ignoreWriteErrors = False
    
    #types of elements that are able to be selected
    e = [Class, Package]

    # grab item selected in containment tree
    browser = mainFrame.getBrowser()
    cTree = browser.getContainmentTree()
    root = cTree.getSelectedNode()
    if root:
        root = root.getUserObject()
    
    # select root <<Power Load Product>> to start from
#    root = Utils.getUserSelection(e, "Select the root <<Power Load Product>> of script")

try:
    validation = PowerLoadCharacterizationValidation(isUserScript, fixMode, root)
    
    validation.run()
    
    scriptOutput = {}
    if validation.hasErrors():
        scriptOutput['DocGenValidationOutput'] = validation.vs
except:
    exceptionType, exceptionValue, exceptionTraceback = sys.exc_info()
    messages = traceback.format_exception(exceptionType, exceptionValue, exceptionTraceback)
    for message in messages:
        gl.log(message)
