#from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Interaction
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Lifeline
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import StateInvariant
from com.nomagic.uml2.ext.magicdraw.commonbehaviors.mdsimpletime import DurationConstraint
from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import State
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import ElementValue
from gov.nasa.jpl.mbee.lib import Utils
from gov.nasa.jpl.mgss.mbee.docgen.table import EditableTable
from gov.nasa.jpl.mgss.mbee.docgen.table import PropertyEnum

from javax.swing import JFileChooser
from javax.swing import JOptionPane
import os
#from gov.nasa.jpl.mbee.lib import Utils
#from gov.nasa.jpl.mgss.mbee.docgen.table import PELTable as PELTablej

#from EHM import PELUtils
#reload(PELUtils)
#import MDUtils._MDUtils as MDUtils
#reload(MDUtils)
from EHM import SequenceTimelineUtils
reload(SequenceTimelineUtils)

################################################################################
# Important Note Regarding DocGen Scripts
# Within the parent code from which this Python code is called, a Python dict "scriptInput" is defined. Within this dict, the values of all of the DocGen view's query targets and imports are defined. It also contains the values of the stereotype tags that are specific to the stereotype of the viewpoiont that the view conforms to. The value are specified as a list. Thus, even if the expected value is a Boolean, the Boolean will be stored within a list.

# Get the target queries and the viewpoint tags
targets = scriptInput['DocGenTargets']
model=[]
headers=[]
editable=[]
prop=[]

# Initialize the root product and workpackage
scenario = None

# The target should contain the top-level product and workpackage
for t in targets:
    if isinstance(t, Interaction):
        scenario = t
        break

# Check to make sure the root Product and Workpackages exist.
if scenario is None:
    scriptOutput = "[Error] Scenario sequence interaction is missing!"
# Generate the PEL Data Files if both of the root Product and Workpackage exist.
else:
    scriptOutput = {}

    # Ideally, we would create an appropriate data stucture for
    # Timeline, and add an Event to the Timeline appropriately.
    # As a simple implementation of Timeline, we assume a Timeline
    # to be total-ordered with non-overlapping events. This
    # implementation also assumes that the temporal constraints are
    # only specified as a duration on the events. With this
    # simplication, we implement Timeline as simply an ordered list
    # of events.
    timeline = SequenceTimelineUtils.generateTimeline(scenario)    
    if timeline:
        #scenarioTimelineCsv = []
        #scenarioTimelineCsv.append("Power Load Mode" + ", " +
        #                          "Duration [hr]" + "\n")
        headers.append("Power Load Mode")#,"Duration [hr]") 
        #prop.append(PropertyEnum.NAME)
        headers.append("Duration [hr]")
        #prop.append(PropertyEnum.NAME)
        #editable.append(True)
        #editable.append(True)
        for e in timeline:
            #scenarioTimelineCsv.append(SequenceTimelineUtils.getEventTypeName(e) + ", " +
             #                          str(SequenceTimelineUtils.getDuration(e)) + "\n")
            model.append([SequenceTimelineUtils.getEventType(e),str(SequenceTimelineUtils.getDuration(e))])
            prop.append(PropertyEnum.NAME)
            editable.append(True)
            #turing into string, because you can't edit yet
            #model.append(str(SequenceTimelineUtils.getDuration(e)))
            #Can't do this yet, because editable table doesn't work with constraint
            #prop.append(PropertyEnum.VALUE)
            editable.append(False)#can't edit yet (constraint)
#        fileChooser = JFileChooser()
#        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY)
#        fileChooser.setDialogTitle("Save power scenario timeline at...")
#        retval = fileChooser.showSaveDialog(None)
#        if retval == JFileChooser.APPROVE_OPTION:
#            if fileChooser.getSelectedFile():
#                saveDir = fileChooser.getSelectedFile()
#                fileName = saveDir.toString() + ((os.name=='nt') and '\\' or '/') + "scenarioTimeline.csv"
#                JOptionPane.showMessageDialog(None, "Saved the file at:\n" + fileName)
#                timelineFile = open(fileName, 'w')
#                timelineFile.writelines(scenarioTimelineCsv)
#                timelineFile.close()
        table=EditableTable("ScenarioTimeline",model,headers,[editable],[prop],None)
        table.setEditableCol(editable)
        table.setWhatToShowCol(prop)
        table.prepareTable()
        docgenTable=Utils.getDBTableFromEditableTable(table,False)
        
        scriptOutput={"EditableTable": table}
        scriptOutput["DocGenOutput"]= [docgenTable]
    else:
        scriptOutput = "The scenario model is not valid."
