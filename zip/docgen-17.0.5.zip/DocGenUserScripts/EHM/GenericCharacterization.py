from com.nomagic.magicdraw.core import Application
from com.nomagic.magicdraw.openapi.uml import SessionManager
from com.nomagic.magicdraw.openapi.uml import ModelElementsManager
from com.nomagic.magicdraw.openapi.uml import PresentationElementsManager

from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import *
from com.nomagic.uml2.ext.magicdraw.classes.mddependencies import *
from com.nomagic.uml2.ext.magicdraw.classes.mdinterfaces import *
from com.nomagic.uml2.ext.magicdraw.actions.mdbasicactions import *
from com.nomagic.uml2.ext.magicdraw.activities.mdbasicactivities import *
from com.nomagic.uml2.ext.magicdraw.activities.mdintermediateactivities import *
from com.nomagic.uml2.ext.magicdraw.auxiliaryconstructs.mdinformationflows import *
from com.nomagic.uml2.ext.magicdraw.activities.mdfundamentalactivities import *
from com.nomagic.uml2.ext.magicdraw.interactions.mdfragments import *
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import *
from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import *
from com.nomagic.magicdraw.uml.symbols.layout import *
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper, ModelHelper

from gov.nasa.jpl.mgss.mbee.docgen.validation import ValidationRule
from gov.nasa.jpl.mgss.mbee.docgen.validation import ValidationSuite
from gov.nasa.jpl.mgss.mbee.docgen.validation import ViolationSeverity

import sys, traceback

from gov.nasa.jpl.mbee.lib import Utils
from gov.nasa.jpl.mgss.mbee.docgen.table import EditableTable, PropertyEnum

# logging levels as globals...
ERROR   = 0
WARNING = 1
INFO    = 2
CONSOLE = 3 # always print console
LOG_STRINGS         = ["ERROR", "WARNING", "INFO", "CONSOLE"]

PRODUCT_ST          = " Product"
CHAR_ST             = " Characterization"
BHVR_CHAR_ST        = " Behavior Characterization"

# global map of WPs
wp2product = {}
wpHierarchy = {}


'''
Characterization pattern is:

+ Product
  + Behavior Characterization (Modes)
    + Characterization
      + Properties
        + Default Value and Units
        
So, in building a table, need to get the total number of properties (along with units)
'''
class Product:
    def __init__(self, product):
        self._product = None
        self._modes = None
        self._children = None
        self._wp = None
        
        self._setProduct(product)
        
    def load(self):
        self._modes = self._findModes()
        self._children = self._findChildren()
        self._wp = self._findWorkPackage()
    
    def _setProduct(self, product):
        # lets get the characterization string
        for st in StereotypesHelper.getStereotypes(product):
            stName = st.getName()
            if stName.endswith(PRODUCT_ST):
                stPrefix = stName.replace(PRODUCT_ST, "")
                self.productSt = "%s%s" % (stPrefix, PRODUCT_ST)
                self.charSt = "%s%s" % (stPrefix, CHAR_ST)
                self.bhvrCharSt = "%s%s" % (stPrefix, BHVR_CHAR_ST)
                self._product = product
                break
    
    def _findModes(self):
        modes = []
        bhvrChar = None
        # look for the behavior characterization
        for element in filter(lambda x: hasattr(x, "getName"), self._product.getOwnedElement()):
            # for some reason Stereotype isn't available sometimes
            if StereotypesHelper.hasStereotypeOrDerived(element, self.bhvrCharSt) or element.getName().endswith(CHAR_ST):
                bhvrChar = element
                break
        # lets look for characterizations underneath the behavior characterization to get the modes
        if bhvrChar:
            for element in bhvrChar.getOwnedElement():
                if StereotypesHelper.hasStereotypeOrDerived(element, self.charSt):
                    modes.append(element)
        
        return sorted(modes, key=lambda x: x.getName())
    
    def _findChildrenProduct(self, children):
        products = []
        for child in filter(lambda x:hasattr(x, "getType"), children):
            childType = child.getType()
            if childType:
                if StereotypesHelper.hasStereotypeOrDerived(childType, self.productSt):
                    products.append(childType)
        return sorted(products, key=lambda x: x.getName())
    
    def _findChildren(self):
        children = []
        # inherited are named elements, so can't extend with owned elements
        owned = self._product.getInheritedMember()
        children.extend(self._findChildrenProduct(owned))
        
        owned = self._product.getOwnedElement()
        children.extend(self._findChildrenProduct(owned))
                    
        return children
    
    def _findWorkPackage(self):
        target = None
        for dr in self._product.get_directedRelationshipOfTarget():
            if StereotypesHelper.hasStereotypeOrDerived(dr, "supplies"):
                target = ModelHelper.getClientElement(dr)
                if StereotypesHelper.hasStereotypeOrDerived(target, "Work Package"):
                    # add to global wp2product map (make sure its not already there)
                    if not wp2product.has_key(target):
                        wp2product[target] = set()
                    found = False
                    for product in wp2product[target]:
                        if product.getProduct() == self._product:
                            found = True
                    if not found:
                        wp2product[target].add(self)
                    break
        if not target:
            gl.log("[WARNING]: No work package found for %s" % self.getName())
        return target
    
    def getModeProperties(self, mode):
        properties = []
        for property in filter(lambda x: isinstance(x, Property), mode.getOwnedElement()):
            properties.append(property)
        return sorted(properties, key=lambda x: x.getName())
    
    def getChildren(self):
        return self._children

    def getName(self):
        return self._product.getName()

    def getModes(self):
        return self._modes

    def getProduct(self):
        return self._product
    
    def getWp(self):
        return self._wp
    
    def hasChildren(self):
        return True if self._children else False
    
    def hasModes(self):
        return True if self._modes else False

    def hasProduct(self):
        return True if self._product else False
    
    def hasWp(self):
        return True if self._wp else False
        
    def __str__(self):
        string = ""
        string += "%s: %s\n" % (self.productSt, self._product.getName())
        if self._modes:
            string += "  Modes:\n"
            for mode in self._modes:
                string += "    %s\n" % mode.getName()
        if self._children:
            string += "  Children Products:\n"
            for child in self._children:
                string += "    %s\n" % child.getName()
        return string.strip()


class GenericCharacterization:
    
    def __init__(self):
        '''
        Constructor initializes member variables
        '''
        self.debugLevel = INFO

        # Grab all project and application specific managers
        self.gl = Application.getInstance().getGUILog()
        self.project = Application.getInstance().getProject()
        self.ef = self.project.getElementsFactory()
        self.mem = ModelElementsManager.getInstance()
        self.pem = PresentationElementsManager.getInstance()
        
        # check to see if called from user script then get DG to validate
        self.isUserScript = self.checkIfUserScript()
        self.getRootNode()
        
        self.log(CONSOLE, "Running GenericCharacterization with debug level %d" % (self.debugLevel))

        self.maxWpDepth = 0
    
    def checkIfUserScript(self):
        '''
        Simple method that checks for scriptInput variable that indicates it was called
        as a User Script.
        
        @return: TRUE if called from User Script, FALSE if called from Macro engine
        '''
        # only way to check for existence of variable is NameError exception
        try:
            inputs = scriptInput["DocGenTargets"]
            self.fixMode = scriptInput["FixMode"]
        except NameError:
            return False
        return True
    
    
    def getRootNode(self):
        '''
        Gets the root node (DGView diagram) based on User Script inputs or the macro (which
        gets the selected node in the containment tree)
        '''
        if self.isUserScript:
            self.root = scriptInput["DocGenTargets"][0]
        else:
            if Utils.getUserYesNoAnswer("Select YES to display just part composition or NO to display WBS"):
                self.showWbs = False
            else:
                self.showWbs = True
            self.root = Application.getInstance().getMainFrame().getBrowser().getContainmentTree().getSelectedNode()
            if self.root:
                self.root = self.root.getUserObject()
    
    
    def log(self, level, message):
        '''
        Debugging feature that only logs when self.debugLevel is greater than the log message level
        
        @param level:    Level of the log message
        @param message:  String to be logged
        '''
        if self.debugLevel >= level or level == CONSOLE:
            self.gl.log("[%s] %s" % (LOG_STRINGS[level], message))


    def run(self):
        '''
        Executes the auto-organization of the view
        '''
        # check that a valid DGView is selected
        if not self.root:
            self.log(ERROR, "Nothing selected\n\tPlease select a <<Product>> in the containment tree")
            return -1
        
        product = Product(self.root)
        
        if not product.hasProduct():
            self.log(ERROR, "Please select a <<Product>> in the containment tree")
            return -1
        else:
            self.log(INFO, "User selected <<%s>>: %s" % (product.productSt, self.root.getName()))

        # see whether or not to fix the diagram

        product.load()
        self.fillWpHierarchy(product.getWp())

        self.checkAndFix()
                    
    def fillWpHierarchy(self, wp, curDepth = 0):
        if wp:
            for dr in wp.get_directedRelationshipOfSource():
                if StereotypesHelper.hasStereotypeOrDerived(dr, "authorizes"):
                    target = ModelHelper.getSupplierElement(dr)
                    if StereotypesHelper.hasStereotypeOrDerived(target, "Work Package"):
                        if not wpHierarchy.has_key(wp):
                            wpHierarchy[wp] = set()
                        wpHierarchy[wp].add(target)
                        self.fillWpHierarchy(target, curDepth+1)
            if curDepth+1 > self.maxWpDepth:
                self.maxWpDepth = curDepth+1

    def productRowGenerator(self, product):
        product.load()
        for index, mode in enumerate(product.getModes()):
            self.log(INFO, "found mode: %s" % (mode.getName()))
            row = []
            if index == 0:
                row.append(product.getProduct())
            else:
                row.append("")
            row.append(mode)
            row.extend(product.getModeProperties(mode))
            yield row

    def generateWpTable(self, wp, numCols, table=[], curDepth=0):
        # add current wp row
        row = []
        for column in range(self.maxWpDepth):
            if column == curDepth:
                row.append(wp)
            else:
                row.append("")
        for column in range(numCols):
            row.append("")
        self.log(INFO, "appending WP [%s] row: %s" % (wp.getName(), row))
        table.append(row)
        
        # add any products
        if wp2product.has_key(wp):
            products = sorted(wp2product[wp], key=lambda x: x.getName())
            for product in products:
                self.log(INFO, "appending PRODUCT [%s] for WP [%s]" % (product.getName(), wp.getName()))
                pgen = self.productRowGenerator(product)
                try:
                    while True:
                        row = []
                        for column in range(self.maxWpDepth):
                            row.append("")
                        prow = pgen.next()
                        row.extend(prow)
                        self.log(INFO, "appending product row [%s]: %s" % (product.getName(), row))
                        table.append(row)
                except StopIteration:
                    pass
        
        # call self recursively on children
        if wpHierarchy.has_key(wp):
            for child in sorted(wpHierarchy[wp], key=lambda x: x.getName()):
                table.extend(self.generateWpTable(child, numCols, [], curDepth+1))
            
        return table

    def generateTable(self, product, table=[]):
        self.log(INFO, "adding product %s" % (product.getName()))
        pgen = self.productRowGenerator(product)
        try:
            while True:
                prow = pgen.next()
                table.append(prow)
                self.log(INFO, "appending row for %s: %s" % (product.getName(), prow))
        except StopIteration:
            pass
        
        # add any children
        if product.hasChildren() or not product.hasModes():
            # if not leaf, look for children
            for child in product.getChildren():
                self.log(INFO, "adding child %s" % child.getName())
                table.extend(self.generateTable(Product(child), []))

        return table
    
    
    def getHeaders(self, table):
        headers = ["Product", "Mode"]
        for row in table:
            for property in row[2:]:
                header = "%s (%s)" % (property.getName().title(), property.getType().getName().title())
                headers.append(header)
            break
        return headers


    def checkAndFix(self, fix=False):
        '''
        Checks and fixes a View by creating a hyperlinked diagram that includes all the imports,
        conforms, First, NoSections in the diagram.
        
        @param fix:    FALSE if just checking for conformance, TRUE if enforcing conformance
        '''
       
        product = Product(self.root)
        table = self.generateTable(product)
        headers = self.getHeaders(table)
        
        # need to get number of columns (which is based off just the properties)
        for row in table:
            numCols = len(row)
            break
        
        # lets create the EditableTable
        if self.showWbs:
            wpTable = self.generateWpTable(product.getWp(), numCols = numCols)
            wpHeaders = []
            for col in range(self.maxWpDepth):
                wpHeaders.append("Work Package")
            wpHeaders = wpHeaders + headers
            headers = wpHeaders
            guiTable = EditableTable("%s Table for %s" % (product.productSt, product.getWp().getName()), wpTable, wpHeaders, None, None, 2)
            
        else:
            guiTable = EditableTable("%s Table for %s" % (product.productSt, product.getName()), table, headers, None, None, 2)
        editableCol = []
        whatToShowCol = []
        numNames = len(headers) - numCols - 2
        for column in range(len(headers)):
            editableCol.append(True)
            if column < numNames:
                whatToShowCol.append(PropertyEnum.NAME)
            else:
                whatToShowCol.append(PropertyEnum.VALUE)
        guiTable.setWhatToShowCol(whatToShowCol)
        guiTable.setEditableCol(editableCol)
        guiTable.prepareTable()
        guiTable.showTable()


gl = Application.getInstance().getGUILog()

# wrap the execution in try block so we can see any exceptions
try:            
    gc = GenericCharacterization()
    gc.run()
except:
    exceptionType, exceptionValue, exceptionTraceback = sys.exc_info()
    messages = traceback.format_exception(exceptionType, exceptionValue, exceptionTraceback)
    for message in messages:
        gl.log(message)

