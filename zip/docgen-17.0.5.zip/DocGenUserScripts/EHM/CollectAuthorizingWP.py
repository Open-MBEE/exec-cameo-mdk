from com.nomagic.magicdraw.core import Application
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from com.nomagic.magicdraw.openapi.uml import SessionManager
from com.nomagic.magicdraw.openapi.uml import ModelElementsManager
from com.nomagic.uml2.ext.jmi.helpers import ModelHelper

import sys
import traceback
import os

from gov.nasa.jpl.mbee.lib import Utils
from gov.nasa.jpl.mbee import DocGenUtils

gl = Application.getInstance().getGUILog()
project = Application.getInstance().getProject()
ef = project.getElementsFactory()
mem = ModelElementsManager.getInstance()

scriptOutput = None
targets = scriptInput['DocGenTargets']

wp = "project:Authority" #name of authority stereotype
auth = "europa:authorizes" #name of authorization stereotype

def hasST(element, string):
    result = StereotypesHelper.hasStereotypeOrDerived(element, StereotypesHelper.getStereotype(project, string))
    return result

def CollectAuthorizingWP(element):
    result = None
    ds = []
    for d in element.getSupplierDependency():
        if hasST(d, auth):
            ds.append(d)
    if len(ds) == 0:
        if element.getOwner() is not None:
            result = element.getOwner()
        #else:
        #   result = "UNAUTHORIZED ELEMENT"
    elif len(ds) == 1:
        result = ds[0].getClient()[0]
    elif len(ds) > 1:
        result = ds[0].getClient()[0]
        gl.log("WARNING: The " + StereotypesHelper.getFirstVisibleStereotype(element).getName() + " " + element.getName() + " has " + str(len(ds)) + " dependencies stereotyped as " + auth + ". This is not allowed! Check it's specification to fix the problem. Qualified name: " + element.getQualifiedName())
    if result is not None:
        if hasST(result, wp):
            return result
        else:
            return CollectAuthorizingWP(result)
    else:
        return None

output = []
for t in targets:
    r = CollectAuthorizingWP(t)
    if r is not None:
        output.append(r)

scriptOutput = {'DocGenOutput':output}