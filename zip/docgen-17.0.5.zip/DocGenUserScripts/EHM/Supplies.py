from com.nomagic.magicdraw.core import Application
from EHM import EHMSupplies
reload(EHMSupplies)

gl = Application.getInstance().getGUILog()

targets = []
if 'DocGenTargets' in scriptInput:
    targets.extend(scriptInput['DocGenTargets'])

validateOnly = False
supplies2Asso = False
authorizes2Asso = False
if scriptInput['FixMode'] == "FixNone":
    validateOnly = True
if len(scriptInput['supplies2Asso']) > 0 and scriptInput['supplies2Asso'][0]:
    supplies2Asso = True
if len(scriptInput['authorizes2Asso']) > 0 and scriptInput['authorizes2Asso'][0]:
    authorizes2Asso = True
    
scriptOutput = {}
if len(targets) > 0:
    for selected in targets:
        validator = EHMSupplies.EHM(selected, supplies2Asso, authorizes2Asso)
        validator.findErrors()
        table = validator.printErrors()
        if validateOnly:
            scriptOutput['DocGenOutput'] = [table]
        else:
            validator.fixErrors()