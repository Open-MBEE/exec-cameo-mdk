### This script creates an editable table and a DocGen table that presents
### power scenarios with additional thermal information and restrictions. There
### are two boolean optional inputs: one is to show the information on the
### thermal loop (onLoop = True) or show the information off the thermal loop
### (onLoop = False), the other is to show a detailed breakdown of leaf elements
### (workpackageSummary = False) or to show just a summary of work packages and
### their totals (workpackageSummary = True).

### Author: David Coren, JPL


from com.nomagic.magicdraw.core import Application
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from com.nomagic.magicdraw.openapi.uml import SessionManager
from com.nomagic.magicdraw.openapi.uml import ModelElementsManager
from com.nomagic.uml2.ext.jmi.helpers import ModelHelper
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import Enumeration
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import AggregationKindEnum
from com.nomagic.uml2.ext.magicdraw.compositestructures.mdports import Port
from com.nomagic.magicdraw.teamwork.application import TeamworkUtils
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Lifeline
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import StateInvariant
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Interaction
from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import State
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import ElementValue
from com.nomagic.uml2.ext.magicdraw.commonbehaviors.mdsimpletime import DurationConstraint
from gov.nasa.jpl.mel import ModelLib

from javax.swing import JOptionPane
from javax.swing import JCheckBox
from java.lang import Object
from jarray import array
import sys
import traceback
import os

from gov.nasa.jpl.mbee.lib import Utils
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTable
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBText
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBColSpec
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTableEntry
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBParagraph
from gov.nasa.jpl.mbee import DocGenUtils
from gov.nasa.jpl.mel import PELTable as PELTablej
from gov.nasa.jpl.mgss.mbee.docgen.table import EditableTable
from gov.nasa.jpl.mgss.mbee.docgen.table import PropertyEnum

from EHM import PELUtils
reload(PELUtils)
from EHM import PELRollup as Rollup
reload(Rollup)
from EHM import ThermalUtils as TA
reload(TA)

gl = Application.getInstance().getGUILog()
project = Application.getInstance().getProject()
ef = project.getElementsFactory()
mem = ModelElementsManager.getInstance()

model = []      #this is for the editable table body
headers = []    #this is for the editable table header
editable = []   #this is whether the table columns are editable
prop = []       #this is what should be edited for each column

scriptOutput = None

product = None
workpackage = None


targets = scriptInput['DocGenTargets']

importedModes = []
for t in targets:  #separate out the top product and workpackage
    if ModelLib.isPLProduct(t):
        product = t
    elif ModelLib.isWorkPackage(t):
        workpackage = t
    elif StereotypesHelper.hasStereotypeOrDerived(t, "Mode Scenario"):
        importedModes.append(t)


if len(importedModes) == 0:
    for behavior in product.getOwnedBehavior():
        if StereotypesHelper.hasStereotypeOrDerived(behavior, "Mode Scenario"):
            importedModes.append(behavior)
            
importedModes.sort()

if product is None or workpackage is None:
    scriptOutput = "product or workpackage missing"
else:
    scriptOutput = {}
    plps = TA.getOwnedPLPs(product)
    suppliedproducts = TA.getSuppliedProducts(workpackage)
    leafplps = TA.getOwnedLeafPLPs(product)

    #find products both supplied and deployed
    targetitems = []
    for p in plps:
        if p.getType() in suppliedproducts:
            targetitems.append(p)

    targetleafitems = []
    for p in leafplps:
        if p.getType() in suppliedproducts:
            targetleafitems.append(p)

    onLoop = True
    if "onLoop" in scriptInput:
        onLoop = scriptInput["onLoop"][0]

    wp_sum = True
    if "workpackageSummary" in scriptInput:
        wp_sum = scriptInput['workpackageSummary'][0]

    thermal_prods = filter(lambda x: StereotypesHelper.hasStereotypeOrDerived(x.getType(), StereotypesHelper.getStereotype(project, "Thermal Load Product")), targetitems)

    loopLeafPLPs = {}
    loopLeafPLPslist = []

    for tp in thermal_prods:
        if TA.ownsPLPs(tp.getType()) is True:
            loopLeafPLPs[tp.getType()] = TA.getOwnedLeafPLPs(tp.getType())
            loopLeafPLPslist.extend(loopLeafPLPs[tp.getType()])
        else:
            loopLeafPLPs[tp.getType()] = tp
            loopLeafPLPslist.append(tp)

    offLoopLeafPLPs = []

    for l in targetleafitems:
        if l not in loopLeafPLPslist:
            offLoopLeafPLPs.append(l)

    if onLoop is False:
        itemsForTable = offLoopLeafPLPs
    else:
        itemsForTable = loopLeafPLPslist

    row_one = [workpackage.getName()]
    if wp_sum is False:
        row_one.extend(["",""])
    for mode in importedModes:
        row_one.extend(["","","",""])

    model.append(row_one)

    wp1cbe = {}
    wp1mev = {}
    
    for authWP1 in sorted(TA.getAuthorizedWPs(workpackage)):
        wp1row = []
        wp1row.append("> " + authWP1.getName())
        if wp_sum is False:
            wp1row.extend(["",""])
        for mode in importedModes:
            wp1row.extend(["","","",""])
        model.append(wp1row)
        wp2cbe = {}
        wp2mev = {}
        for authWP2 in sorted(TA.getAuthorizedWPs(authWP1)):
            wp2cbe[authWP2] = {}
            wp2mev[authWP2] = {}
            wprow = []
            wprow.append("> > " + authWP2.getName())
            if wp_sum is False:
                wprow.extend(["",""])
            for mode in importedModes:
                wprow.extend(["","","",""])
            model.append(wprow)
            wpParts = TA.getSuppliedProducts(authWP2)
            wp3cbe = {}
            wp3mev = {}
            for mode in importedModes:
                wp3cbe[mode] = 0
                wp3mev[mode] = 0
                wp2cbe[authWP2][mode] = 0
                wp2mev[authWP2][mode] = 0
            for plp in sorted(itemsForTable):
                if plp.getType() in wpParts:
                    plpT = plp.getType()
                    if plp.getUpper() is not None:
                        mult = plp.getUpper()
                    else:
                        mult = 1
                    nrow = []
                    nrow.append("")
                    nrow.append(plpT.getName() + " (" + plp.getName() + ")")
                    nrow.append(str(mult))
                    for mode in importedModes:
                        lifeline = PELUtils.findLifelineIncludingInherited(mode, plp)
                        if lifeline is None:
                            gl.log("ERROR: " + plp.getName() + ": " + plp.getType().getName() + " has no lifeline defined!")
                        if len(lifeline.getCoveredBy()) == 1:
                            plc = PELUtils.getPLCForState(lifeline.getCoveredBy()[0].getInvariant().getSpecification().getElement())
                            cbe = float(PELUtils.findProperty(plc, "steady-state power CBE").getDefault())
                            mev = float(PELUtils.findProperty(plc, "steady-state power MEV").getDefault())
                            plcname = plc.getName()
                        else:
                            cbe = float(0)
                            mev = float(0)
                            plcname = ""
                            for state in lifeline.getCoveredBy():
                                dutyCycle = float(state.get_constraintOfConstrainedElement()[0].getSpecification().getMin().getExpr().getValue().split("%")[0])/100
                                plc = PELUtils.getPLCForState(lifeline.getCoveredBy()[0].getInvariant().getSpecification().getElement())
                                cbe += dutyCycle * float(PELUtils.findProperty(plc, "steady-state power CBE").getDefault())
                                mev += dutyCycle * float(PELUtils.findProperty(plc, "steady-state power MEV").getDefault())
                                plcname += plc.getName() + ", "
                        try:
                            cont = round(float(PELUtils.findProperty(plc, "contingency").getDefault()), 2)
                        except:
                            cont = PELUtils.findProperty(plc, "contingency").getDefault()
                        wp3cbe[mode] += cbe*mult
                        wp3mev[mode] += mev*mult
                        wp2cbe[authWP2][mode] += wp3cbe[mode]
                        wp2mev[authWP2][mode] += wp3mev[mode]
                        plcname = plcname.rstrip(", ")
                        nrow.append(plcname)
                        nrow.extend([round(cbe, 2), cont, round(mev, 2)])
                    if wp_sum is False:
                        model.append(nrow)
            i=0
            for mode in importedModes:
                i+=1
                for row in model:
                    if row[0] == "> > " + authWP2.getName():
                        c = -2
                        if wp_sum is False:
                            c = 0
                        row[i*4+c] = round(wp3cbe[mode], 2)
                        row[i*4+2+c] = round(wp3mev[mode], 2)
                        if wp3cbe[mode] != 0:
                            row[i*4+1+c] = round((wp3mev[mode]-wp3cbe[mode])/wp3cbe[mode], 2)
                        else:
                            row[i*4+1+c] = float(0)
        i=0
        for mode in importedModes:
            i+=1
            for row in model:
                if row[0] == "> " + authWP1.getName():
                    c = -2
                    if wp_sum is False:
                        c = 0
                    wp2cbe[mode] = 0
                    wp2mev[mode] = 0
                    for authWP2 in sorted(TA.getAuthorizedWPs(authWP1)):
                        for row2 in model:
                            if row2[0] == "> > " + authWP2.getName():
                                wp2cbe[mode] += row2[i*4+c]
                                wp2mev[mode] += row2[i*4+2+c]
                    row[i*4+c] = round(wp2cbe[mode], 2)
                    row[i*4+2+c] = round(wp2mev[mode], 2)
                    if wp2cbe[mode] != 0:
                        row[i*4+1+c] = round((wp2mev[mode]-wp2cbe[mode])/wp2cbe[mode], 2)
                    else:
                        row[i*4+1+c] = float(0)
    i=0
    for mode in importedModes:
        i+=1
        for row in model:
            if row[0] == workpackage.getName():
                c = -2
                if wp_sum is False:
                    c = 0
                wp1cbe[mode] = 0
                wp1mev[mode] = 0
                for authWP1 in sorted(TA.getAuthorizedWPs(workpackage)):
                    for row1 in model:
                        if row1[0] == "> " + authWP1.getName():
                            wp1cbe[mode] += row1[i*4+c]
                            wp1mev[mode] += row1[i*4+2+c]
                row[i*4+c] = round(wp1cbe[mode], 2)
                row[i*4+2+c] = round(wp1mev[mode], 2)
                if wp1cbe[mode] != 0:
                    row[i*4+1+c] = round((wp1mev[mode]-wp1cbe[mode])/wp1cbe[mode], 2)
                else:
                    row[i*4+1+c] = float(0)
    
    headers = ["Workpackage"]
    if wp_sum is False:
        headers.append("Product")
        headers.append("Number of Units")
    for mode in importedModes:
        if wp_sum is False:
            headers.append(mode.getName() + " State")
        headers.append(mode.getName() + " CBE per unit")
        headers.append(mode.getName() + " cont")
        headers.append(mode.getName() + " MEV per unit")
    if onLoop is True:
        title = "On Loop electric power usage info"
    if onLoop is False:
        title = "Off Loop electric power usage info"
    table = EditableTable(title, model, headers, None, None, None)
    table.prepareTable()
    scriptOutput['EditableTable'] = table
    dbheader1 = []
    dbheader2 = []
    colspec  = []
    dbheaderstart = ["", "Work Package"]
    if wp_sum is False:
        dbheaderstart.extend(["Product", "Number of Units"])
    if wp_sum is True:
        for row in model:
            j=0
            for mode in importedModes:
                row.remove("")
    for h in dbheaderstart:
        ln = DBTableEntry()
        ln.addElement(DBText(h))
        ln.setMorerows(1)
        dbheader1.append(ln)
    for mode in importedModes:
        m = DBTableEntry()
        m.addElement(DBText(mode.getName() + " Electric power usage"))
        colnum = int(importedModes.index(mode))*2 + 3
        m.setNamest(str(colnum))
        colspec.append(DBColSpec(colnum))
        if wp_sum is False:
            m.setNameend(str(colnum + 3))
            colspec.append(DBColSpec(colnum + 3))
        else:
            m.setNameend(str(colnum + 2))
            colspec.append(DBColSpec(colnum + 2))
        dbheader1.append(m)
        if wp_sum is False:
            dbheader2.extend([DBText("State"), DBText("CBE [W] per unit"), DBText("contingency"), DBText("MEV [W] per unit")])
        else:
            dbheader2.extend([DBText("CBE [W] per unit"), DBText("contingency"), DBText("MEV [W] per unit")])
    dbheaders = [dbheader1, dbheader2]
    docgenTable = Utils.getDBTableFromEditableTable(table, True)
    docgenTable.setColspecs(colspec)
    docgenTable.setHeaders(dbheaders)
    scriptOutput["DocGenOutput"] = [docgenTable]

