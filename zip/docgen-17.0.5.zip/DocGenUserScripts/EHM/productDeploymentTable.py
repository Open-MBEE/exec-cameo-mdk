#Created By:  Louise Anderson, louise.anderson@jpl.nasa.gov
#Europa Product Deployment Table

from gov.nasa.jpl.mgss.mbee.docgen.table import EditableTable
from gov.nasa.jpl.mgss.mbee.docgen.table import PropertyEnum
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTable
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBText
from com.nomagic.magicdraw.core import Application
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import *
from gov.nasa.jpl.mbee.lib import Utils
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper, ModelHelper
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBParagraph, DBTable, DBTableEntry, DBText


gl = Application.getInstance().getGUILog()


#This gives a one row table for editing names of the targets and also 
#a output table for docgen

targets = scriptInput['DocGenTargets']

model = []      #this is for the table body
headers = []    #this is for the table header
editable = []   #this is whether the table cells are editable
prop = [] #this is what should be edited
row = []
#tableTitle="Europa Product Deployment Table"
table = DBTable()


docgenBody = []     #this is for the DocGen UserScript table body
project = Application.getInstance().getProject()
wP = StereotypesHelper.getStereotype(project,'Work Package','Project Profile')
role=StereotypesHelper.getStereotype(project,'Role','Project Profile')
ff=StereotypesHelper.getStereotype(project,'fulfills')
delv=StereotypesHelper.getStereotype(project,'Delivers')
cD=StereotypesHelper.getStereotype(project,'Concept Description Document','Project Profile')
wG=StereotypesHelper.getStereotype(project,'Working Group','Project Profile')
iS=StereotypesHelper.getStereotype(project,'Task Iteration','Project Profile')
acctF=StereotypesHelper.getStereotype(project,'accountableFor')
sup=StereotypesHelper.getStereotype(project,'supplies')
pS=StereotypesHelper.getStereotype(project,'ProjectStaff','Project Profile')
rSt=StereotypesHelper.getStereotype(project,'Role','Project Profile')
projectProf=StereotypesHelper.getProfile(project,"Project Profile")
projSt=StereotypesHelper.getStereotypesByProfile(projectProf)
#gl.log(acctF.getName())

def getOwnedElementsByStereotype(parentElement, stereotype = "Block"):
    return filter(lambda element: StereotypesHelper.hasStereotype(element, stereotype), parentElement.getOwnedElement())

def getOwnedElementsByStereotypes(parentElement, stereotypes):
    return filter(lambda element: all(StereotypesHelper.hasStereotype(element, stereotype) \
                                      for stereotype in stereotypes), 
                  parentElement.getOwnedElement())
    
    
def collectRelationshipEndsByStereotype(source, s, supplier):
    """
    get related elements related with given stereotype (includes derived)
    params:
        a model element
        a stereotype element
        boolean: whether to treat model element as source or target of relationship
    returns:
        list of model elements, empty list if none"""
    relevant = []
    rs = None
    if supplier:
        rs = source.get_directedRelationshipOfTarget()
    else:
        rs = source.get_directedRelationshipOfSource()
    for r in rs:
        if StereotypesHelper.hasStereotypeOrDerived(r, s):
            if supplier:
                relevant.append(ModelHelper.getClientElement(r))
            else:
                relevant.append(ModelHelper.getSupplierElement(r))
    return relevant

work=targets[0]
#gl.log(targets[0].getName())
workItrs=targets[1]
#gl.log(targets[1].getName())
#elems=work.getOwnedElements()
workGrps=filter(lambda element: StereotypesHelper.hasStereotype(element, wG), work.getOwnedElement())
itrs=filter(lambda element: StereotypesHelper.hasStereotype(element, iS), workItrs.getOwnedElement())
for i in itrs:
    #gl.log(i.getName())
#for w in workGrps:
#    gl.log(w.getName())
#assuming import is a package of iterations and a package of working groups
    row.append(DBParagraph(i.getName())) #1
    docs=collectRelationshipEndsByStereotype(i, delv, False)  #this is for the document column
    wbsT = DBTableEntry()
    docT=DBTableEntry()
    docTyT=DBTableEntry()
    roleT=DBTableEntry()
    wkGrpT=DBTableEntry()
    for d in docs:
        people=[]
        wbs=collectRelationshipEndsByStereotype(d, sup, True)
        
        for t in wbs:
            #gl.log(t.getName())
            wbsT.addElement(DBParagraph(t.getName())) #2
            gl.log(t.getName())
        #dbTableEntry() #multiple db things inside here
         #2
        #gl.log(t.getName())
        #row.append(d)
        
        #doing table stuff for the document
        docT.addElement(DBParagraph(d.getName()))
        #gl.log(d.getName())
        
        #getting document types
        docType=StereotypesHelper.getStereotypes(d)
        #row.append(docType)
        #doing table stuff for the document type
        
        
        docType=filter(lambda element: element in projSt, docType)
        for j in docType:
                docTyT.addElement(DBParagraph(j.getName()))
        
        
        #getting the roles for the different documents
        
        roles=collectRelationshipEndsByStereotype(d, acctF, True)  #True reverse collects the elements,  #this is potentially not only the roles....
        #row.append(roles)
        
        for r in roles:
            #table stuff for roles
            #gl.log(r.getName())
            if StereotypesHelper.hasStereotype(r,rSt):
                roleT.addElement(DBParagraph(r.getName()))
                rAttrs=r.getOwnedAttribute()
                for rA in rAttrs:
                    rT=rA.getType()
                    if StereotypesHelper.hasStereotype(rT,pS):
                        people.append(rT)
                    #gl.log(rT.getName())
            #once we have people can get the relevant working groups that have those people
                for w in workGrps:
                    #gl.log("This is the name of a working group ===>"+ w.getName())
                    attrs=w.getOwnedAttribute()
                    for attr in attrs:
                        #not actually getting in this "if"
                        #gl.log(attr.getType().getName())
                        if attr.getType() in people:
                            #gl.log("This is the working group that has people  " + w.getName())
                            #list=list.append(w)
                            wkGrpT.addElement(DBParagraph(w.getName()))
                            #gl.log("Check")
            elif StereotypesHelper.hasStereotype(r,wG):
                roleT.addElement(DBParagraph(""))
                wkGrpT.addElement(DBParagraph(r.getName()))
            #people=collectRelationshipEndsByStereotype(r, ff, True)  #need to change this to more complicated people collection
            #first get the attributes then get the types, check that the types have ProjectStaff Stereotype if they do add that element to the list of people
            
            #row.append(list)
            
    row.append(wbsT) #2    #finishing adding roles
    row.append(wkGrpT)#3
    row.append(docT) #4
    row.append(docTyT) #5
    row.append(roleT)#6
    docgenBody.append(row)
    #gl.log(str(docgenBody))
    row=[]


table.setBody(docgenBody)
table.setTitle("Europa Product Deployment Table")
headers = [[DBText("Iteration"), DBText("WBS Element"),DBText("Working Group"),DBText("Product"),DBText("Product Type"), DBText("Role")]]
table.setHeaders(headers)
table.setCols(6)
output=[table]
scriptOutput ={"DocGenOutput":output}