from com.nomagic.magicdraw.core import Application
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from gov.nasa.jpl.mel import ModelLib
from com.nomagic.magicdraw.openapi.uml import SessionManager
from com.nomagic.magicdraw.openapi.uml import ModelElementsManager
from com.nomagic.uml2.ext.jmi.helpers import ModelHelper
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import Enumeration
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import AggregationKindEnum
from com.nomagic.uml2.ext.magicdraw.compositestructures.mdports import Port
from com.nomagic.magicdraw.teamwork.application import TeamworkUtils
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Lifeline
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import StateInvariant
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Interaction

from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import State
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import ElementValue
from com.nomagic.uml2.ext.magicdraw.commonbehaviors.mdsimpletime import DurationConstraint

from javax.swing import JOptionPane
from javax.swing import JCheckBox
from java.lang import Object
from jarray import array
import sys
import traceback
import os

from gov.nasa.jpl.mbee.lib import Utils
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTable
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBText
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBColSpec
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTableEntry
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBParagraph
from gov.nasa.jpl.mbee import DocGenUtils
from gov.nasa.jpl.mel import PELTable as PELTablej
from gov.nasa.jpl.mgss.mbee.docgen.table import EditableTable
from gov.nasa.jpl.mgss.mbee.docgen.table import PropertyEnum

from EHM import PELUtils
reload(PELUtils)
from EHM import PELRollup as Rollup
reload(Rollup)

gl = Application.getInstance().getGUILog()
project = Application.getInstance().getProject()
ef = project.getElementsFactory()
mem = ModelElementsManager.getInstance()

contingencys = "contingency"
cbes = "steady-state power CBE"
mevs = "steady-state power MEV"

model = []      #this is for the editable table body
headers = []    #this is for the editable table header
editable = []   #this is whether the table columes are editable
prop = []       #this is what should be edited for each colume

isEditable = False
scriptOutput = None
wps = None
wp2p = None
wpdepth = None
p2plc = None
wp2plc = None
maxmodes = 0
p2i = None
p2p = None
modesList = None
p2unit = None

product = None
workpackage = None

moreRows = {} #{rownum: what moreRows should be set to}
rownum = 1

def fillModelTable(curwp, curdepth):
    '''fills in the 2d array for editable table,
       each cell holds either magicdraw element or string
       calls itself recursively for each child workpackage, each workpackage takes 1 row, its supplied leaf products also take 1 row each
       workpackages are indented based on the hierarhcy
       power modes and their properties are shown horizontally for each product
    '''
    global rownum
    currow = []
    for i in range(curdepth-1):
        currow.append("")
    currow.append(curwp)
    for i in range(wpdepth-curdepth):
        currow.append("")
    currow.append("")
    currow.append("")
    for mode in modesList:
        currow.extend(["", ""])
        plc = PELUtils.findWpPLCForMode(curwp, mode, wp2plc)
        if plc is not None:
            currow.append(PELUtils.findProperty(plc, cbes))
            currow.append(PELUtils.findProperty(plc, contingencys))
            currow.append(PELUtils.findProperty(plc, mevs))
        else:
            currow.extend([None, None, None])
    model.append(currow)
    rownum = rownum + 1
    for p in sorted(wp2p[curwp], key=PELUtils.sortByNameKey):
        for prop in sorted(p2p[p], key=PELUtils.sortByNameKey):
            pstates = 0
            stateplcs = {}
            prow = []
            for i in range(wpdepth):
                prow.append("")
            prow.append(p.getName() + " (" + prop.getName() + ")")
            prow.append(p2unit[prop])
            for mode in modesList:
                lifeline = PELUtils.findLifeline(prop, mode, product, p2i)
                if lifeline is None:
                    continue
                plcs = PELUtils.getStatePlcs2percent(lifeline)
                numstates = len(plcs)
                if numstates > pstates:
                    pstates = numstates
                stateplcs[mode] = plcs
            
            if pstates == 0:
                continue
            
            if pstates == 1:
                for mode in modesList:
                    if mode not in stateplcs or len(stateplcs[mode]) == 0:
                        prow.extend(["", "", "", "", ""])
                    else:
                        plc = stateplcs[mode].keys()[0]
                        prow.append(plc)
                        prow.append("")
                        prow.append(PELUtils.findProperty(plc, cbes))
                        prow.append(PELUtils.findProperty(plc, contingencys))
                        prow.append(PELUtils.findProperty(plc, mevs))
                model.append(prow)
                rownum = rownum + 1
            elif pstates > 1:
                for mode in modesList:
                    if mode not in stateplcs or len(stateplcs[mode]) == 0:
                        prow.extend(["", "", "", "", ""])
                    elif len(stateplcs[mode]) == 1:
                        plc = stateplcs[mode].keys()[0]
                        prow.append(plc)
                        prow.append("")
                        prow.append(PELUtils.findProperty(plc, cbes))
                        prow.append(PELUtils.findProperty(plc, contingencys))
                        prow.append(PELUtils.findProperty(plc, mevs))
                    else:
                        plcs = stateplcs[mode]
                        prow.append(PELUtils.getCombinedPlcName(plcs))
                        prow.append("")
                        prow.append(Utils.floatTruncate(str(PELUtils.getCombinedPlcCbe(plcs)), 2))
                        prow.append(PELUtils.getCombinedPlcContingency(plcs))
                        prow.append(Utils.floatTruncate(str(PELUtils.getCombinedPlcMev(plcs)), 2))
                model.append(prow)
                moreRows[rownum] = pstates
                rownum = rownum + 1
                for i in range(pstates):
                    nrow = ["", ""]
                    for j in range(wpdepth):
                        nrow.append("")
                    for mode in modesList:
                        if mode not in stateplcs or len(stateplcs[mode]) < 2:
                            nrow.extend(["", "", "", "", ""])
                        else:
                            plcs = stateplcs[mode]
                            if len(plcs) > i:
                                plcsorted = sorted(plcs.keys(), key=PELUtils.sortByNameKey)
                                plc = plcsorted[i]
                                nrow.append(plc)
                                nrow.append(str(plcs[plc]) + "%")
                                nrow.append(PELUtils.findProperty(plc, cbes))
                                nrow.append(PELUtils.findProperty(plc, contingencys))
                                nrow.append(PELUtils.findProperty(plc, mevs))
                            else:
                                nrow.extend(["", "", "", "", ""])
                    model.append(nrow)
                    rownum = rownum + 1
            
    for childwp in sorted(wps[curwp], key=PELUtils.sortByNameKey):
        fillModelTable(childwp, curdepth+1)
            
def fillDbHeaders(dbheader1, dbheader2, dbheader3, colspecs):
    ln = DBTableEntry()
    ln.addElement(DBText(""))
    ln.setMorerows(2)
    wp = DBTableEntry()
    wp.addElement(DBText("Workpackage"))
    wp.setMorerows(2)
    product = DBTableEntry()
    product.addElement(DBText("Product"))
    product.setMorerows(2)
    units = DBTableEntry()
    units.addElement(DBText("Number of Units"))
    units.setMorerows(2)
    dbheader1.extend([ln, wp, product, units])
    for i in range(len(modesList)):
        namest = 1+3+i*5+1
        nameend = 1+3+i*5+5
        colspecs.append(DBColSpec(namest))
        colspecs.append(DBColSpec(nameend))
        mode = DBTableEntry()
        mode.addElement(DBText(DocGenUtils.fixString(modesList[i])))
        mode.setNamest(str(namest))
        mode.setNameend(str(nameend))
        modeD = DBTableEntry()
        for M in importedModes:
            if M.getName() == modesList[i]:
                modeD.addElement(DBParagraph(ModelHelper.getComment(M)))
        modeD.setNamest(str(namest))
        modeD.setNameend(str(nameend))
        dbheader1.append(mode)
        dbheader2.extend([DBText("State"), DBText("Duration [%]"), DBText("Avg Pwr CBE per Unit [W]"), DBText("Contingency"), DBText("Avg Pwr MEV per Unit [W]")])
        dbheader3.append(modeD)

def fixMoreRows(body):
    for r in moreRows:
        morerows = moreRows[r]
        product = body.get(r-1).get(2)
        unit = body.get(r-1).get(3)
        newproduct = DBTableEntry()
        newproduct.setMorerows(morerows)
        newproduct.addElement(product)
        newunit = DBTableEntry()
        newunit.addElement(unit)
        newunit.setMorerows(morerows)
        body.get(r-1).set(2, newproduct)
        body.get(r-1).set(3, newunit)
        for i in range(morerows):
            body.get(r+i).remove(2)
            body.get(r+i).remove(2)
    
targets = scriptInput['DocGenTargets'] #get the stuff passed in 
importedModes = []
for t in targets:  #separate out the top product and workpackage
    if ModelLib.isPLProduct(t):
        product = t
    elif ModelLib.isWorkPackage(t):
        workpackage = t
    elif isinstance(t, Interaction):
        importedModes.append(t)
        
if product is None or workpackage is None:
    scriptOutput = "product or workpackage missing"
else:
    scriptOutput = {}
    includeInherited = False
    if len(scriptInput['includeInherited']) > 0 and scriptInput['includeInherited'][0]:
        includeInherited = True
    helper = PELTablej(product, workpackage, importedModes, False, False, includeInherited)
    #helper = PELTablej(product, workpackage, False, False) #use the helper
    helper.fillGraphs()
    wps = helper.getWpDeployment() #workpackage hierarhcy
    wp2p = helper.getWp2LeafP()    #workpackage to leaf products mapping
    wpdepth = helper.getWpDepth()  #workpackage depth (top is depth 1)
    p2plc = helper.getP2plc()      #product to power load characterizations mapping
    wp2plc = helper.getWp2plc()    #workpackage to power load characterizations mapping
    p2p = helper.getP2p()          #product to parent properties mapping
    p2i = helper.getP2i()          #product to mode interactions mapping
    modesList = helper.getModes()      #all possible modes as strings
    modesList = sorted(modesList)
    p2unit = helper.getTotalUnits()
    #do some calculations??
    fix = False
    if not "FixMode" in scriptInput:
       fix = not Utils.getUserYesNoAnswer("Validate only?")
    
    if "FixMode" in scriptInput and scriptInput["FixMode"] != "FixNone":
        fix = True
    rollup = Rollup.PELRollup(modesList, wps, workpackage, product, wp2p, p2p, p2i, wp2plc, p2plc, fix, p2unit, helper)
    rollup.doall(False)
    if rollup.hasErrors():
        scriptOutput["DocGenValidationOutput"] = rollup.getValidationSuites() #this is for the validation output
  
    
    fillModelTable(workpackage, 1)
    #below: fill in the editable table metadata (editable columes, what to show, etc)
    # the workpackage columes
    for i in range(wpdepth): 
        editable.append(True) if isEditable else editable.append(False)
        headers.append("Workpackage")
        prop.append(PropertyEnum.NAME)
    # the product colume
    editable.append(False) #this has the part name in parentheses
    headers.append("Product")
    prop.append(PropertyEnum.NAME)
    # multiplicity
    editable.append(False)
    headers.append("Number of Units")
    prop.append(PropertyEnum.NAME)
    # modes, power mode cannot be editable since it's an enumeration
    for m in modesList:
        headers.append(m + " State")
        headers.append(m + " Duration [%]")
        headers.append(m + " Avg Pwr CBE per Unit [W]")
        headers.append(m + " Contingency")
        headers.append(m + " Avg Pwr MEV per Unit [W]")
        editable.extend([False, False, True, True, True]) if isEditable else editable.extend([False, False, False, False, False])
        prop.extend([PropertyEnum.NAME, PropertyEnum.NAME, PropertyEnum.VALUE, PropertyEnum.VALUE, PropertyEnum.VALUE])
    
    table = EditableTable("PEL Modes Detail for " + workpackage.getName(), model, headers, [editable], [prop], 2)
    table.setEditableCol(editable)
    table.setWhatToShowCol(prop)
    table.prepareTable()

    #get the docgen table for output to document, this util translates the editable table to docbook table, the last param is for compressing the 
    #separate workpackage hierarchy columes into single colume with indenting.
    
    scriptOutput["EditableTable"] = table          #this is for the editable table
    #if not rollup.hasErrors():
    docgenTable = Utils.getDBTableFromEditableTable(table, True, [wpdepth]) 
    colspecs = []
    dbheaders1 = []
    dbheaders2 = []
    dbheaders3 = []
    dbheaders = [dbheaders1, dbheaders3, dbheaders2]
    fillDbHeaders(dbheaders1, dbheaders2, dbheaders3, colspecs)
    docgenTable.setColspecs(colspecs)
    docgenTable.setHeaders(dbheaders)
    fixMoreRows(docgenTable.getBody())
    
    scriptOutput["DocGenOutput"] = [];
    if rollup.hasErrors():
        for vs in rollup.getValidationSuites():
            for docElem in vs.getDocBook():
                scriptOutput["DocGenOutput"].append(docElem)
            
    scriptOutput["DocGenOutput"].append(docgenTable) 