from com.nomagic.magicdraw.core import Application
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from gov.nasa.jpl.mel import ModelLib
from com.nomagic.magicdraw.openapi.uml import SessionManager
from com.nomagic.magicdraw.openapi.uml import ModelElementsManager
from com.nomagic.uml2.ext.jmi.helpers import ModelHelper
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import Enumeration
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import AggregationKindEnum
from com.nomagic.uml2.ext.magicdraw.compositestructures.mdports import Port
from com.nomagic.magicdraw.teamwork.application import TeamworkUtils

from javax.swing import JOptionPane
from javax.swing import JCheckBox
from java.lang import Object
from jarray import array
import sys
import traceback
import os

from gov.nasa.jpl.mbee.lib import Utils
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTable
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBText
from gov.nasa.jpl.mbee import DocGenUtils
from gov.nasa.jpl.mel import PELTable as PELTablej
from gov.nasa.jpl.mgss.mbee.docgen.table import EditableTable
from gov.nasa.jpl.mgss.mbee.docgen.table import PropertyEnum

gl = Application.getInstance().getGUILog()
project = Application.getInstance().getProject()
ef = project.getElementsFactory()
mem = ModelElementsManager.getInstance()

contingency = "contingency"
cbe = "steady-state power CBE"
mev = "steady-state power MEV"
mode = "power mode"

model = []      #this is for the editable table body
headers = []    #this is for the editable table header
editable = []   #this is whether the table columes are editable
prop = []       #this is what should be edited for each colume

isEditable = False
scriptOutput = None
wps = None
wp2p = None
wpdepth = None
p2plc = None
#maxmodes = 0

def findProperty(plc, pname):
    '''find a property in power load characterization based on name'''
    for p in plc.getOwnedAttribute():
        if p.getName() == pname:
            return p
    return None

def sortByNameKey(e):
    '''key function for sorting, this is what's used for comparison'''
    return e.getName()

def fillModelTable(curwp, curdepth):
    '''fills in the 2d array for editable table, also calculates the max number of modes for the whole table
       each cell holds either magicdraw element or string
       calls itself recursively for each child workpackage, each workpackage takes 1 row, its supplied leaf products also take 1 row each
       workpackages are indented based on the hierarhcy
       power modes and their properties are shown horizontally for each product
    '''
    #global maxmodes
    currow = []
    for i in range(curdepth-1):
        currow.append("")
    currow.append(curwp)
    for i in range(wpdepth-curdepth):
        currow.append("")
    currow.extend(["", "", "", "", "", ""])
    model.append(currow)
    for product in sorted(wp2p[curwp], key=sortByNameKey):
        prow = []
        for i in range(wpdepth):
            prow.append("")
        prow.append(product)
        modes = 0
        if len(p2plc[product]) == 0:
            prow.extend(["", "", "", ""])
            model.append(prow)
            continue
        sortedplc = sorted(p2plc[product], key=sortByNameKey)
        first = sortedplc[0]
#        firstdir=''
#        for value in dir(first):
#            firstdir += value + "\n"
        #gl.log(firstdir)
        #return
        prow.append(first)
        prow.append(findProperty(first, cbe))
        prow.append(findProperty(first, contingency))
        prow.append(findProperty(first, mev))
        prow.append(ModelHelper.getComment(first))
        model.append(prow)
        for plc in sortedplc[1:]:
            nrow = []
            for i in range(wpdepth):
                nrow.append("")
            nrow.append("")
            nrow.append(plc)
            nrow.append(findProperty(plc, cbe))
            nrow.append(findProperty(plc, contingency))
            nrow.append(findProperty(plc, mev))
            nrow.append(ModelHelper.getComment(plc))
            model.append(nrow)
    for childwp in sorted(wps[curwp], key=sortByNameKey):
        fillModelTable(childwp, curdepth+1)
            


targets = scriptInput['DocGenTargets'] #get the stuff passed in 
product = None
workpackage = None
for t in targets:  #separate out the top product and workpackage
    if ModelLib.isPLProduct(t):
        product = t
    elif ModelLib.isWorkPackage(t):
        workpackage = t

if product is None or workpackage is None:
    scriptOutput = "product or workpackage missing"
else:
    includeInherited = False
    if len(scriptInput['includeInherited']) > 0 and scriptInput['includeInherited'][0]:
        includeInherited = True
    helper = PELTablej(product, workpackage, False, False, includeInherited)
    #helper = PELTablej(product, workpackage, False, False) #use the helper
    helper.fillGraphs()
    wps = helper.getWpDeployment() #workpackage hierarhcy
    wp2p = helper.getWp2LeafP()    #workpackage to leaf products mapping
    wpdepth = helper.getWpDepth()  #workpackage depth (top is depth 1)
    p2plc = helper.getP2plc()      #product to power load characterization mapping

    fillModelTable(workpackage, 1)

    #below: fill in the editable table metadata (editable columes, what to show, etc)
    # the workpackage columes
    for i in range(wpdepth): 
        editable.append(True) if isEditable else editable.append(False)
        headers.append("Work Package")
        prop.append(PropertyEnum.NAME)
    # the product colume
    editable.append(True) if isEditable else editable.append(False) #
    headers.append("Product")
    prop.append(PropertyEnum.NAME)
    # modes, power mode cannot be editable since it's an enumeration
    #for i in range(maxmodes):
    headers.append("Power Mode")
    headers.append("Avg Pwr CBE per Unit [W]")
    headers.append("Contingency")
    headers.append("Avg Pwr MEV per Unit [W]")
    headers.append("Notes")
    editable.append(False)
    editable.append(True) if isEditable else editable.append(False)
    editable.append(True) if isEditable else editable.append(False)
    editable.append(True) if isEditable else editable.append(False)
    prop.extend([PropertyEnum.NAME, PropertyEnum.VALUE, PropertyEnum.VALUE, PropertyEnum.VALUE])
    
    table = EditableTable("PEL Table for " + workpackage.getName(), model, headers, [editable], [prop], 2)
    table.setEditableCol(editable)
    table.setWhatToShowCol(prop)
    table.prepareTable()

    #get the docgen table for output to document, this util translates the editable table to docbook table, the last param is for compressing the 
    #separate workpackage hierarchy columes into single colume with indenting.
    docgenTable = Utils.getDBTableFromEditableTable(table, True, [wpdepth]) 

    scriptOutput = {"EditableTable":table}          #this is for the editable table
    scriptOutput["DocGenOutput"] = [docgenTable]    #this is for the docgen output table

