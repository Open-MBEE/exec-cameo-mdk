from com.nomagic.magicdraw.core import Application
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from com.nomagic.magicdraw.openapi.uml import SessionManager
from com.nomagic.magicdraw.openapi.uml import ModelElementsManager
from com.nomagic.uml2.ext.jmi.helpers import ModelHelper
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import Enumeration
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import AggregationKindEnum
from com.nomagic.uml2.ext.magicdraw.compositestructures.mdports import Port
from com.nomagic.magicdraw.teamwork.application import TeamworkUtils

from javax.swing import JOptionPane
from javax.swing import JCheckBox
from java.lang import Object
from jarray import array
import sys
import traceback
import os

from gov.nasa.jpl.mbee.lib import Utils
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTable
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBText
from gov.nasa.jpl.mgss.mbee.docgen import DocGenUtils

gl = Application.getInstance().getGUILog()
project = Application.getInstance().getProject()
ef = project.getElementsFactory()
mem = ModelElementsManager.getInstance()
sm = SessionManager.getInstance()

class EHM:
    def __init__(self, folder, sdepen2asso, adepen2asso):
        self.errors = {} # 
        self.folder = folder
        self.reverse = {} # {product:[wp,...]}
        self.missing = []
        self.sdepen2asso = sdepen2asso
        self.adepen2asso = adepen2asso
        
    def findErrors(self):
        workpackages = self.findWorkPackages()
        for wp in workpackages:
            errors = {}
            self.errors[wp] = errors
            self.fillwperrors(wp, errors)
        products = self.findProducts()
        self.fillProductErrors(products)
        return self.errors
    
    def fillProductErrors(self, products):
        for p in products:
            if p not in self.reverse:
                self.missing.append(p)
    
    def findErrors1(self, wp, change, delete, duplicate, depenS, typeS):
        '''change association to dependency'''
        keep = []
        found = []
        for p in wp.getOwnedAttribute():
            ptype = p.getType()
            if ptype is not None and StereotypesHelper.hasStereotypeOrDerived(ptype, typeS):
                existing = self.getDepen(wp, ptype, depenS)
                if len(existing) == 0 and ptype not in found:
                    change.append(p)
                    found.append(ptype)
                elif ptype in found:
                    delete.append(p)
                elif len(existing) == 1:
                    delete.append(p)
                    found.append(ptype)
                    keep.extend(existing)
                elif len(existing) > 1:
                    change.append(p)
                    found.append(ptype)
                    duplicate.extend(existing)
                if depenS == 'supplies':
                    if ptype not in self.reverse:
                        self.reverse[ptype] = [wp]
                    elif wp not in self.reverse[ptype]:
                        self.reverse[ptype].append(wp)
        for rel in wp.get_directedRelationshipOfSource():
            supplier = ModelHelper.getSupplierElement(rel)
            if StereotypesHelper.hasStereotypeOrDerived(rel, depenS) and StereotypesHelper.hasStereotypeOrDerived(supplier, typeS):
                if supplier not in found:
                    found.append(supplier)
                elif rel not in duplicate and rel not in keep:
                    duplicate.append(rel)
                if depenS == 'supplies':
                    if supplier not in self.reverse:
                        self.reverse[supplier] = [wp]
                    elif wp not in self.reverse[supplier]:
                        self.reverse[supplier].append(wp)
                    
    def findErrors2(self, wp, change, delete, duplicate, depenS, typeS, wrongAggr):
        '''change dependency to association'''
        keep = []
        found = []
        for rel in wp.get_directedRelationshipOfSource():
            supplier = ModelHelper.getSupplierElement(rel)
            if StereotypesHelper.hasStereotypeOrDerived(rel, depenS) and StereotypesHelper.hasStereotypeOrDerived(supplier, typeS):
                existing = self.getAsso(wp, supplier)
                if len(existing) == 0 and supplier not in found:
                    change.append(rel)
                    found.append(supplier)
                elif supplier in found:
                    delete.append(rel)
                elif len(existing) == 1:
                    delete.append(rel)
                    found.append(supplier)
                    keep.extend(existing)
                    if existing[0].getAggregation() != AggregationKindEnum.SHARED:
                        wrongAggr.append(existing[0])
                elif len(existing) > 1:
                    change.append(rel)
                    found.append(supplier)
                    duplicate.extend(existing)
                if depenS == 'supplies':
                    if supplier not in self.reverse:
                        self.reverse[supplier] = [wp]
                    elif wp not in self.reverse[supplier]:
                        self.reverse[supplier].append(wp)
        for p in wp.getOwnedAttribute():
            ptype = p.getType()
            if ptype is not None and StereotypesHelper.hasStereotypeOrDerived(ptype, typeS):
                if ptype not in found:
                    found.append(ptype)
                    if p.getAggregation() != AggregationKindEnum.SHARED:
                        wrongAggr.append(p)
                elif p not in duplicate and p not in keep:
                    duplicate.append(p)
                if depenS == 'supplies':
                    if ptype not in self.reverse:
                        self.reverse[ptype] = [wp]
                    elif wp not in self.reverse[ptype]:
                        self.reverse[ptype].append(wp)
    
    def fillwperrors(self, wp, errors):
        suppliesChange = []
        authorizesChange = []
        suppliesDelete = []
        authorizesDelete = []
        suppliesDuplicate = []
        authorizesDuplicate = []
        suppliesWrongAggr = []
        authorizesWrongAggr = []
        if self.sdepen2asso:
            self.findErrors2(wp, suppliesChange, suppliesDelete, suppliesDuplicate, 'supplies', 'Product', suppliesWrongAggr)
        else:
            self.findErrors1(wp, suppliesChange, suppliesDelete, suppliesDuplicate, 'supplies', 'Product')
        if self.adepen2asso:
            self.findErrors2(wp, authorizesChange, authorizesDelete, authorizesDuplicate, 'authorizes', 'Work Package', authorizesWrongAggr)
        else:
            self.findErrors1(wp, authorizesChange, authorizesDelete, authorizesDuplicate, 'authorizes', 'Work Package')
            
        errors['suppliesChange'] = suppliesChange
        errors['authorizesChange'] = authorizesChange
        errors['suppliesDelete'] = suppliesDelete
        errors['authorizesDelete'] = authorizesDelete
        errors['suppliesDuplicate'] = suppliesDuplicate
        errors['authorizesDuplicate'] = authorizesDuplicate
        errors['suppliesWrongAggr'] = suppliesWrongAggr
        errors['authorizesWrongAggr'] = authorizesWrongAggr
        
    def getDepen(self, wp, ptype, type):
        res = []
        for rel in wp.get_directedRelationshipOfSource():
            if StereotypesHelper.hasStereotypeOrDerived(rel, type) and ModelHelper.getSupplierElement(rel) is ptype:
                res.append(rel)
        return res
    
    def getAsso(self, wp, ptype):
        res = []
        for p in wp.getOwnedAttribute():
            if p.getType() is not None and p.getType() == ptype:
                res.append(p)
        return res
        
    def findWorkPackages(self):
        es = Utils.collectOwnedElements(self.folder, 0)
        return Utils.filterElementsByStereotypeString(es, 'Work Package', True, True)
    
    def findProducts(self):
        es = Utils.collectOwnedElements(self.folder, 0)
        return Utils.filterElementsByStereotypeString(es, 'Product', True, True)
    
    def printErrors1(self, errors, type, body):
        '''change association to dependency'''
        change = type + 'Change'
        delete = type + 'Delete'
        duplicate = type + 'Duplicate'
        if len(errors[change]) > 0:
            gl.log("\t" + type + " properties to be converted to dependencies:")
            for p in errors[change]:
                gl.log("\t\t" + p.getQualifiedName())
                body.append([DBText(DocGenUtils.fixString(p.getQualifiedName())), DBText("Property should be converted to " + type + " dependency.")])
        if len(errors[delete]) > 0:
            gl.log("\t" + type + " properties to be deleted:")
            for p in errors[delete]:
                gl.log("\t\t" + p.getQualifiedName())
                body.append([DBText(DocGenUtils.fixString(p.getQualifiedName())), DBText("Property should be deleted")])
        if len(errors[duplicate]) > 0:
            gl.log("\tDuplicate " + type + " dependencies to be deleted (to):")
            for rel in errors[duplicate]:
                gl.log("\t\t" + ModelHelper.getSupplierElement(rel).getQualifiedName())
                body.append([DBText(DocGenUtils.fixString(ModelHelper.getSupplierElement(rel).getQualifiedName())), DBText("Element that's the target of a duplicate " + type + " dependency.")])
    
    def printErrors2(self, errors, type, body):
        '''change dependency to association'''
        change = type + 'Change'
        delete = type + 'Delete'
        duplicate = type + 'Duplicate'
        wrongAggr = type + "WrongAggr"
        if len(errors[change]) > 0:
            gl.log("\t" + type + " dependencies (to) to be converted to properties:")
            for rel in errors[change]:
                gl.log("\t\t" + ModelHelper.getSupplierElement(rel).getQualifiedName())
                body.append([DBText(DocGenUtils.fixString(ModelHelper.getSupplierElement(rel).getQualifiedName())), DBText("Dependency should be converted to " + type + " property.")])
        if len(errors[delete]) > 0:
            gl.log("\t" + type + " dependencies to be deleted (to):")
            for rel in errors[delete]:
                gl.log("\t\t" + ModelHelper.getSupplierElement(rel).getQualifiedName())
                body.append([DBText(DocGenUtils.fixString(ModelHelper.getSupplierElement(rel).getQualifiedName())), DBText(type + " dependency should be deleted")])
        if len(errors[duplicate]) > 0:
            gl.log("\tDuplicate " + type + " properties to be deleted:")
            for p in errors[duplicate]:
                gl.log("\t\t" + p.getQualifiedName())
                body.append([DBText(DocGenUtils.fixString(p.getQualifiedName())), DBText(type + " duplicate property to be deleted.")])
        if len(errors[wrongAggr]) > 0:
            gl.log("\tWrong aggregation " + type + " property:")
            for p in errors[wrongAggr]:
                gl.log("\t\t" + p.getQualifiedName())
                body.append([DBText(DocGenUtils.fixString(p.getQualifiedName())), DBText(type + " property has wrong aggregation.")])
    
    def printErrors(self):
        table = DBTable()
        body = []
        for wp in self.errors:
            gl.log("Printing Errors for WorkPackage " + wp.getQualifiedName() + ":")
            errors = self.errors[wp]
            if self.sdepen2asso:
                self.printErrors2(errors, 'supplies', body)
            else:
                self.printErrors1(errors, 'supplies', body)
            if self.adepen2asso:
                self.printErrors2(errors, 'authorizes', body)
            else:
                self.printErrors1(errors, 'authorizes', body)
        gl.log("Products with multiple work packages associated:")
        for product in self.reverse:
            if len(self.reverse[product]) > 1:
                gl.log("\t" + product.getQualifiedName())
                body.append([DBText(DocGenUtils.fixString(product.getQualifiedName())), DBText("Product with multiple work packages associated")])
                for wp in self.reverse[product]:
                    gl.log("\t\t" + wp.getQualifiedName())
        gl.log("Products with no work package associated:")
        for p in self.missing:
            gl.log("\t" + p.getQualifiedName())
            body.append([DBText(DocGenUtils.fixString(p.getQualifiedName())), DBText("Product with no work package associated")])
        table.setBody(body)
        table.setHeaders([[DBText("Element"), DBText("Problem")]])
        table.setCols(2)
        table.setTitle("EHM Supplies Relationship Validation")
        return table
    
    def fixErrors1(self, wp, errors, type):
        '''change association to dependency'''
        change = type + 'Change'
        delete = type + 'Delete'
        duplicate = type + 'Duplicate'
        for p in errors[change]:
            ptype = p.getType()
            depen = ef.createDependencyInstance()
            ModelHelper.setClientElement(depen, wp)
            ModelHelper.setSupplierElement(depen, ptype)
            depen.setOwner(wp.getOwner())
            StereotypesHelper.addStereotypeByString(depen, type) #shodul make sure this is the right stereotype
            mem.removeElement(p)
        for p in errors[delete]:
            mem.removeElement(p)
        for rel in errors[duplicate]:
            mem.removeElement(rel)
            
    def fixErrors2(self, wp, errors, type):
        '''change dependency to association'''
        change = type + 'Change'
        delete = type + 'Delete'
        duplicate = type + 'Duplicate'
        wrongAggr = type + "WrongAggr"
        for rel in errors[change]:
            supplier = ModelHelper.getSupplierElement(rel)
            asso = ef.createAssociationInstance()
            p = asso.getMemberEnd().get(0)
            p2 = asso.getMemberEnd().get(1)
            asso.setOwner(wp.getOwner())
            p.setType(supplier)
            p2.setType(wp)
            p.setOwner(wp)
            p2.setOwner(asso)
            p.setAggregation(AggregationKindEnum.SHARED)
            p.setName(supplier.getName())
            mem.removeElement(rel)
        for rel in errors[delete]:
            mem.removeElement(rel)
        for p in errors[duplicate]:
            mem.removeElement(p)
        for p in errors[wrongAggr]:
            p.setAggregation(AggregationKindEnum.SHARED)
                     
    def fixErrors(self):
        for wp in self.errors:
            if not wp.isEditable():
                gl.log("ERROR: " + wp.getQualifiedName() + " is not editable")
                continue
            errors = self.errors[wp]
            if self.sdepen2asso:
                self.fixErrors2(wp, errors, 'supplies')
            else:
                self.fixErrors1(wp, errors, 'supplies')
            if self.adepen2asso:
                self.fixErrors2(wp, errors, 'authorizes')
            else:
                self.fixErrors1(wp, errors, 'authorizes')
