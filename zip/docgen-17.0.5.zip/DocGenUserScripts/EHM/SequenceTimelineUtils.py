from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Interaction
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import InteractionFragment
from com.nomagic.uml2.ext.magicdraw.interactions.mdfragments import InteractionOperatorKindEnum
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Lifeline
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import StateInvariant
from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import StateMachine
from com.nomagic.uml2.ext.magicdraw.commonbehaviors.mdsimpletime import DurationConstraint
from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import State
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import ElementValue

from javax.swing import JOptionPane

def getEventTypeName(event):
    eventType = getEventType(event)
    if isinstance(eventType, StateMachine):
        return eventType.getName()
    else:
        return None
    
def getEventType(event):
    if isinstance(event, StateInvariant):
        constraint = event.getInvariant()
        if constraint is not None and isinstance(constraint.getSpecification(), ElementValue) and isinstance(constraint.getSpecification().getElement(), State) and constraint.getSpecification().getElement().getSubmachine() is not None:
            return constraint.getSpecification().getElement().getSubmachine()
        else:
            # [Error]
            return None
    else:
        # [Error]
        return None

def isLeafDurativeEvent(event):
    ''' A leaf level event is an event without a child event.
    Using UML Sequence syntax to represent an event, a StateInvariant
    is considered to be a leaf level durative event. It is durative
    since a StateInvariant is assumed impossible to occur at only an
    instant in time, i.e. instant event.'''
    if isinstance(event, StateInvariant):
        return True
    else:
        return False

def isCompositeEvent(event):
    ''' As an event represented using UML Sequence syntax,
    an event is composite event, i.e. with child event, if
    and only if the event is an InteractionFragment.'''
    if isinstance(event, InteractionFragment):
        return True
    else:
        return False

def isLoopingEvent(event):
    ''' A Looping Event is a Composite Event that repeats
    either a defined or undefined number of times. As a
    Looping Event represented using UML Sequence syntax,
    an Event is a Looping Event if and only if the Event is
    a Combined Fragement whose Interaction Operator is LOOP.'''
    if isCompositeEvent(event) and event.getInteractionOperator() is InteractionOperatorKindEnum.LOOP:
        return True
    else:
        return False
    
def getChildEvents(event):
    ''' Returns child events if any exist.
    If none exist, an empty list is returned.
    An event is expected to have child events, if
    the event is a composite event.'''
    if isLoopingEvent(event):
        return event.getOwnedElement()[0].getFragment()
    elif isCompositeEvent(event):
        return event.getFragment()
    else:
        return []

def getDuration(event):
    durationConstraints = getDurationConstraints(event)
    # From here on, we assume that exactly 1 duration constraint
    # is allowed for an event. We also assume that only min value
    # is defined for the duration constraint and that the max
    # value is the same as that of the min.
    if durationConstraints and len(durationConstraints) > 0:
        intervalMin = None
        for c in durationConstraints:
            interval = c.getSpecification()
            try:
                intervalMin = float(interval.getMin().getExpr().getValue())
                break
            except:
                pass
        return intervalMin
    else:
        return None

def getDurationConstraints(event):
    if isLeafDurativeEvent(event):
        return filter(lambda c: isinstance(c, DurationConstraint),
                      event.get_constraintOfConstrainedElement())
    else:
        return []
    
def appendToTimeline(timeline, event):
    ''' Ideally, we would create an appropriate data stucture for
    Timeline, and add an Event to the Timeline appropriately.
    As a simple implementation of Timeline, we assume a Timeline
    to be total-ordered with non-overlapping events. This
    implementation also assumes that the temporal constraints are
    only specified as a duration on the events. With this
    simplication, we implement Timeline as simply an ordered list
    of events. Thus, appending an event to a Timeline implies
    that the event occurs subsequent to all events on the
    Timeline.'''
    if isLeafDurativeEvent(event):
        timeline.append(event)
    elif isLoopingEvent(event):
        minint = None
        for operand in event.getOperand():
            try:
                minint = int(operand.getGuard().getMinint().getValue())
                break
            except:
                pass
        if minint:
            for i in range(minint):
                # Given the simplified definition of Timeline, we
                # flatten Looping Events.
                for e in getChildEvents(event):
                    appendToTimeline(timeline, e)
        #else:
        # Incomplete specification
    #else:
    # Error

def generateTimeline(scenario):
    '''Ideally, we would create an appropriate data stucture for
    Timeline, and add an Event to the Timeline appropriately.
    As a simple implementation of Timeline, we assume a Timeline
    to be total-ordered with non-overlapping events. This
    implementation also assumes that the temporal constraints are
    only specified as a duration on the events. With this
    simplication, we implement Timeline as simply an ordered list
    of events.'''
    if isinstance(scenario, Interaction):
        timeline = []
        for e in scenario.getFragment():
            appendToTimeline(timeline, e)
        return timeline
    else:
        return None
