from com.nomagic.magicdraw.core import Application
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from com.nomagic.magicdraw.openapi.uml import SessionManager
from com.nomagic.magicdraw.openapi.uml import ModelElementsManager
from com.nomagic.uml2.ext.jmi.helpers import ModelHelper
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import Enumeration
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import AggregationKindEnum
from com.nomagic.uml2.ext.magicdraw.compositestructures.mdports import Port
from com.nomagic.magicdraw.teamwork.application import TeamworkUtils
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Lifeline
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import StateInvariant
from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import State
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import ElementValue
from com.nomagic.uml2.ext.magicdraw.commonbehaviors.mdsimpletime import DurationConstraint

from javax.swing import JOptionPane
from javax.swing import JCheckBox
from java.lang import Object
from jarray import array
import sys
import traceback
import os

from gov.nasa.jpl.mbee.lib import Utils
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTable
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBText
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBColSpec
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTableEntry
from gov.nasa.jpl.mbee import DocGenUtils
from gov.nasa.jpl.mel import PELTable as PELTablej
from gov.nasa.jpl.mgss.mbee.docgen.table import EditableTable
from gov.nasa.jpl.mgss.mbee.docgen.table import PropertyEnum
from gov.nasa.jpl.mgss.mbee.docgen.validation import ValidationRule
from gov.nasa.jpl.mgss.mbee.docgen.validation import ValidationSuite
from gov.nasa.jpl.mgss.mbee.docgen.validation import ViolationSeverity

from EHM import PELUtils
reload(PELUtils)

def rollupPEL(rootWorkpackage, rootProduct, includeInherited = True, fix = False, scriptOutput = {}):
    ''' Given the root Workpackage and Product, perform the rollup.'''
    # Check to make sure the root Product and Workpackages exist.
    if rootProduct is None or rootWorkpackage is None:
        scriptOutput = "[Error] The root Product and/or Workpackage is missing!"
    # Generate the PEL Data Files if both of the root Product and Workpackage exist.
    else:
        scriptOutput = {}

        # Generate the PEL Table
        helper = PELTablej(rootProduct, rootWorkpackage, False, False, includeInherited)
    
        # Generate the necessary graphs give the PEL Table.
        helper.fillGraphs()

        wp2wpChild    = helper.getWpDeployment()  # workpackage hierarhcy
        wp2pdLeaf     = helper.getWp2LeafP()      # workpackage to leaf products mapping
        wpDepth       = helper.getWpDepth()       # workpackage depth (top is depth 1)
        pd2plc        = helper.getP2plc()         # product to power load characterizations mapping
        wp2plc        = helper.getWp2plc()        # workpackage to power load characterizations mapping
        pd2properties = helper.getP2p()           # product to the properties typed by the product
        pd2if         = helper.getP2i()           # product to mode interaction fragments mapping
        modesList     = sorted(helper.getModes()) # all possible modes as strings
        p2unit        = helper.getTotalUnits()    # map of property to total units
        # Initialize the Power Rollup.
        rollup = PELRollup(modesList, wp2wpChild, rootWorkpackage, rootProduct, wp2pdLeaf,
                           pd2properties, pd2if, wp2plc, pd2plc, fix, p2unit, helper)
        # Rollup power.
        rollup.doall()
        # If the rollup has an error, then
        if rollup.hasErrors():
            scriptOutput = "[Error] The power rollup is not up to date. Please fix before continuing!"
            # Return nothing
            return None
        # If there were no errors:
        else:
            # Return the helper
            return helper

class PELRollup:
    def __init__(self, modesList, wps, wp, product, wp2lp, p2p, p2i, wp2plc, p2plc, fix, p2unit, helper):
        self.modesList = modesList
        self.wps = wps
        self.wp2lp = wp2lp
        self.p2p = p2p
        self.p2i = p2i
        self.wp2plc = wp2plc
        self.p2plc = p2plc
        self.workpackage = wp
        self.product = product
        self.p2unit = p2unit
        
        self.pmev = {} #{leaf power load characterization block: mev prpoerty}
        self.pc = {}
        self.pcbe = {}
        
        self.emev = {} #{leaf power load characterization block: expected mev as float}
        self.ec = {}
        self.ecbe = {}
        
        self.modeEmev = {} #{"mode":{partProperty: expected mev as float}} if property is not represented in the mode no key will be there
        self.modeEc = {}
        self.modeEcbe = {}
    
        self.modeWPpmev = {} #{"mode": {workpackage: mev property}}
        self.modeWPpcbe = {}
        self.modeWPpc = {}
        
        self.modeWPemev = {} #{"mode": {workpackage: expected mev as float}}
        self.modeWPec = {}
        self.modeWPecbe = {}
        
        self.fix = fix
        
        self.validationSuites = []
        self.nan = ValidationRule("Value is nan", "Where calculated value is nan, meaning cannot be calculated, probably because there are nans in dependent values", ViolationSeverity.ERROR)
        self.missing = ValidationRule("Value is missing", "Where the property for the value is missing from the model", ViolationSeverity.ERROR)
        self.wrong = ValidationRule("Value is wrong", "Where model value is different from calculated value", ViolationSeverity.ERROR)
        self.illegalPercent = ValidationRule("Illegal percentage", "Part's total power percentage exceeds 100 for a mode", ViolationSeverity.ERROR)
        
        self.log = Application.getInstance().getGUILog()
        self.helper = helper;
        
    def getValidationSuites(self):
        return self.validationSuites
    
    def doall(self, fix):
        vs = ValidationSuite("PEL Validation")
        vs.addValidationRule(self.nan)
        vs.addValidationRule(self.missing)
        vs.addValidationRule(self.wrong)
        vs.addValidationRule(self.illegalPercent)
        self.validationSuites.append(vs)
        
        self.calculateExpectedLeafProductPLCs()
        self.calculateExpectedProductPartPLCForModes()
        self.calculateExpectedWorkpackagePLCs(self.workpackage, fix)
        self.checkLeafPlc()
        self.checkWorkpackages()
        
    
    def isNan(self, num):
        return num != num
    
    def calculateExpectedLeafProductPLCs(self):
        for wp in self.wp2lp:
            for p in self.wp2lp[wp]:
                for plc in self.p2plc[p]:
                    cbe = PELUtils.findProperty(plc, PELUtils.cbes)
                    mev = PELUtils.findProperty(plc, PELUtils.mevs)
                    c = PELUtils.findProperty(plc, PELUtils.contingencys)
                    self.pmev[plc] = mev
                    self.pc[plc] = c
                    self.pcbe[plc] = cbe
                    dcbe = float("nan")
                    dc = float("nan")
                    dmev = float("nan")
                    if cbe is not None:
                        try:
                            dcbe = float(cbe.getDefault())
                        except:
                            pass
                    if c is not None:
                        try:
                            dc = float(c.getDefault())
                        except:
                            pass
                    if c.getDefault() == "n/a":
                        dc = "n/a"
                        dmev = float(mev.getDefault())
                        Application.getInstance().getGUILog().log(c.getQualifiedName() + " is not a number, MEV calculation skipped.")
                    else:
                        dmev = dcbe*(dc+1)
                    self.ecbe[plc] = dcbe
                    self.emev[plc] = dmev
                    self.ec[plc] = dc
        
    def calculateExpectedProductPartPLCForModes(self):
        for mode in self.modesList:
            emev = {}
            ec = {}
            ecbe = {}
            self.modeEmev[mode] = emev
            self.modeEc[mode] = ec
            self.modeEcbe[mode] = ecbe

            for wp in self.wp2lp:
                for p in self.wp2lp[wp]:
                    for prop in self.p2p[p]:
                        totalPercent = 0
                        lifeline = PELUtils.findLifeline(prop, mode, self.product, self.p2i)
                        if lifeline is None:
                            continue
                        statePlcs2percent = PELUtils.getStatePlcs2percent(lifeline)
                        ##Application.getInstance().getGUILog().log(lifeline.getQualifiedName())
                        if len(statePlcs2percent) == 1:
                            plc = statePlcs2percent.keys()[0]
                
                            emev[prop] = self.emev[plc]
                            ec[prop] = self.ec[plc]
                            ecbe[prop] = self.ecbe[plc]
                            totalPercent = statePlcs2percent[plc]
                        elif len(statePlcs2percent) == 0:
                            continue
                        else:
                            mev = 0
                            c = 0
                            cbe = 0
                            for plc in sorted(statePlcs2percent.keys(), key=PELUtils.sortByNameKey):
                                partialMev = self.emev[plc]
                                partialCbe = self.ecbe[plc]
                                percent = statePlcs2percent[plc]
                                totalPercent += percent
                                mev += partialMev*percent/100
                                cbe += partialCbe*percent/100
                            c = mev/cbe - 1
                            emev[prop] = mev
                            ec[prop] = c
                            ecbe[prop] = cbe
                        if totalPercent > 100:
                            self.illegalPercent.addViolation(prop, "Total percent is " + str(totalPercent) + " for mode " + mode)
                    
    def calculateExpectedWorkpackagePLCs(self, curwp, fix):    
        for cwp in self.wps[curwp]:
            self.calculateExpectedWorkpackagePLCs(cwp, fix)        
        for mode in self.modesList:
            if mode not in self.modeWPemev:
                self.modeWPemev[mode] = {}
                self.modeWPec[mode] = {}
                self.modeWPecbe[mode] = {}
            if mode not in self.modeWPpmev:
                self.modeWPpmev[mode] = {}
                self.modeWPpc[mode] = {}
                self.modeWPpcbe[mode] = {}
                
            emev = self.modeWPemev[mode]
            ec = self.modeWPec[mode]
            ecbe = self.modeWPecbe[mode]
            
            pmev = self.modeWPpmev[mode]
            pc = self.modeWPpc[mode]
            pcbe = self.modeWPpcbe[mode]
            
            pemev = self.modeEmev[mode]
            pec = self.modeEc[mode]
            pecbe = self.modeEcbe[mode]
            
            mev = 0
            c = 0
            cbe = 0
            
            for product in sorted(self.wp2lp[curwp], key=PELUtils.sortByNameKey):
                for prop in sorted(self.p2p[product], key=PELUtils.sortByNameKey):
                    if prop not in pemev:
                        continue
                    multiplicity = self.p2unit[prop]
                    partialMev = pemev[prop]*multiplicity
                    partialCbe = pecbe[prop]*multiplicity
                    mev += partialMev
                    cbe += partialCbe
                            
            for cwp in sorted(self.wps[curwp], key=PELUtils.sortByNameKey):
                mev += emev[cwp]
                cbe += ecbe[cwp]
            
            try:
                c = mev/cbe - 1
            except:
                pass
            emev[curwp] = mev
            ecbe[curwp] = cbe
            ec[curwp] = c
            
            plc = PELUtils.findWpPLCForMode(curwp, mode, self.wp2plc)
            if plc is not None:
                pmev[curwp] = PELUtils.findProperty(plc, PELUtils.mevs)
                pcbe[curwp] = PELUtils.findProperty(plc, PELUtils.cbes)
                pc[curwp] = PELUtils.findProperty(plc, PELUtils.contingencys)
            else:    
                
                if fix is True:    
                    plc = self.helper.getPowerCharacterization(mode, curwp)    
                    self.wp2plc.get(curwp).add(plc)
            
                pmev[curwp] = None
                pcbe[curwp] = None
                pc[curwp] = None
                
                if fix is True:
                    pmev[curwp] = PELUtils.findProperty(plc, PELUtils.mevs)
                    pcbe[curwp] = PELUtils.findProperty(plc, PELUtils.cbes)
                    pc[curwp] = PELUtils.findProperty(plc, PELUtils.contingencys)
            
    def checkLeafPlc(self):
        for plc in self.emev:
            pmev = self.pmev[plc]
            pc = self.pc[plc]
            pcbe = self.pcbe[plc]
            emev = self.emev[plc]
            ec = self.ec[plc]
            ecbe = self.ecbe[plc]
            none = False
            if pmev is None:
                self.missing.addViolation(plc, "Missing MEV property")
                none = True
            if pc is None:
                self.missing.addViolation(plc, "Missing contingency property")
                none = True
            if pcbe is None:
                self.missing.addViolation(plc, "Missing CBE property")
                none = True
            if none:
                continue
            if self.ec[plc] != "n/a":
                if self.isNan(emev):
                    self.nan.addViolation(pmev, "Calculated value is nan")
                if self.isNan(ec):
                    self.nan.addViolation(pc, "Calculated value is nan")
            if self.isNan(ecbe):
                self.nan.addViolation(pcbe, "Calculated value is nan")
            mev = pmev.getDefault()
            c = pc.getDefault()
            cbe = pcbe.getDefault()
            self.checkAndFix(emev, mev, pmev)
            self.checkAndFix(ec, c, pc)
            self.checkAndFix(ecbe, cbe, pcbe)
    
    def checkWorkpackages(self):
        for mode in self.modesList:
            wppmev = self.modeWPpmev[mode]
            wppcbe = self.modeWPpcbe[mode]
            wppc = self.modeWPpc[mode]
            wpemev = self.modeWPemev[mode]
            wpecbe = self.modeWPecbe[mode]
            wpec = self.modeWPec[mode]
            for wp in wppmev:
                pmev = wppmev[wp]
                pc = wppc[wp]
                pcbe = wppcbe[wp]
                emev = wpemev[wp]
                ec = wpec[wp]
                ecbe = wpecbe[wp]
                none = False
                if pmev is None:
                    self.missing.addViolation(wp, "Missing MEV property for mode " + mode)
                    none = True
                if pc is None:
                    self.missing.addViolation(wp, "Missing contingency property for mode " + mode)
                    none = True
                if pcbe is None:
                    self.missing.addViolation(wp, "Missing CBE property for mode " + mode)
                    none = True
                if none:
                    continue
                if self.isNan(emev):
                    self.nan.addViolation(pmev, "Calculated value is nan")
                if self.isNan(ec):
                    self.nan.addViolation(pc, "Calculated value is nan")
                if self.isNan(ecbe):
                    self.nan.addViolation(pcbe, "Calculated value is nan")
                mev = pmev.getDefault()
                c = pc.getDefault()
                cbe = pcbe.getDefault()
                self.checkAndFix(emev, mev, pmev)
                self.checkAndFix(ec, c, pc)
                self.checkAndFix(ecbe, cbe, pcbe)
    
    def checkAndFix(self, ev, v, p):
        if self.isNan(ev) or ev == "n/a" or v == "n/a":
            return
        if str(float(ev)) != str(float(v)):
            #if str(ev) == "0" and v == "0.0":
             #   return
            self.wrong.addViolation(p, "Calculated: " + str(ev) + " Model: " + v)
            if self.fix:
                shown = False
                if p.isEditable():
                    Utils.setPropertyValue(p, str(ev))
                else:
                    self.log.log(p.getQualifiedName() + " is not editable!")
                    if not shown:
                        JOptionPane.showMessageDialog(None, p.getQualifiedName() + " is not editable! (Future uneditable things will be shown in the log)", "Bad!", JOptionPane.ERROR_MESSAGE);         
                        shown = True
                    
    def hasErrors(self):
        if len(self.missing.getViolations()) > 0 or len(self.nan.getViolations()) > 0 or len(self.wrong.getViolations()) > 0 or len(self.illegalPercent.getViolations()) > 0:
            return True
        return False
                    
            
                
    
