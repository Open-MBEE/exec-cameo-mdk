from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from javax.swing import JFileChooser
from javax.swing import JOptionPane
from gov.nasa.jpl.mel import ModelLib

from gov.nasa.jpl.mbee.lib import Utils
from gov.nasa.jpl.mel import PELTable as PELTablej

from gov.nasa.jpl.mbee.lib import Utils
from gov.nasa.jpl.mgss.mbee.docgen.table import EditableTable
from gov.nasa.jpl.mgss.mbee.docgen.table import PropertyEnum

import os

from EHM import PELUtils
reload(PELUtils)
from EHM import PELRollup as PELRollup
reload(PELRollup)
import MDUtils._MDUtils as MDUtils
reload(MDUtils)

################################################################################
# Important Note Regarding DocGen Scripts
# Within the parent code from which this Python code is called, a Python dict "scriptInput" is defined. Within this dict, the values of all of the DocGen view's query targets and imports are defined. It also contains the values of the stereotype tags that are specific to the stereotype of the viewpoiont that the view conforms to. The value are specified as a list. Thus, even if the expected value is a Boolean, the Boolean will be stored within a list.

# Get the target queries and the viewpoint tags
targets = scriptInput['DocGenTargets']

#editable table stuff
model=[]
headers=[]
editable=[]
prop=[]

# Initialize the root product and workpackage
rootProduct = None
rootWorkpackage = None



# The target should contain the top-level product and workpackage
for t in targets:
    if ModelLib.isPLProduct(t):
        rootProduct = t
    elif ModelLib.isWorkPackage(t):
        rootWorkpackage = t
        
# Check to make sure the root Product and Workpackages exist.
if rootProduct is None or rootWorkpackage is None:
    scriptOutput = "[Error] The root Product and/or Workpackage is missing!"
# Generate the PEL Data Files if both of the root Product and Workpackage exist.
else:
    scriptOutput = {}

    # Check to see if the inherited parts should be included, with the default is to include.
    includeInherited = True
    if len(scriptInput['includeInherited']) > 0 and not scriptInput['includeInherited'][0]:
        includeInherited = False

    # This script is intended to be only used when the rollup has been fixed
    Fix = False
    
    # Make sure that the rollup is correct, without changing it.
    rollupResult = PELRollup.rollupPEL(rootWorkpackage, rootProduct, includeInherited, Fix,
                                       scriptOutput)

    #pelCsvList = []
    if rollupResult:
        wp2Graph = rollupResult.getWpDeployment() # workpackage hierarhcy
        wp2plc   = rollupResult.getWp2plc()       # workpackage to power load characterizations mapping
#        #pelCsvList.append("Work Package" + ", " +
#                          "Power Load Mode" + ", " +
#                          "Power Load CBE [W]" + ", " +
#                          "Contingency" + ", " +
#                          "Power Load MEV [W]" + "\n")
        headers.append("Work Package")
        headers.append("Power Load Mode")
        headers.append("Power Load CBE [W]")
        headers.append("Contingency")
        headers.append("Power Load MEV [W]")
        for systemWp in wp2Graph[rootWorkpackage]:
            for wp in wp2Graph[systemWp]:
                wpName = wp.getName()
                for plc in sorted(wp2plc[wp], key=PELUtils.sortByNameKey):
                    if plc:
                        plcName = plc.getName()
                        plcCBE  = PELUtils.findProperty(plc,PELUtils.cbes)
                        plcCont = PELUtils.findProperty(plc,PELUtils.contingencys)
                        plcMEV  =  PELUtils.findProperty(plc,PELUtils.mevs)
                        if plcName and not plcCBE is None and not plcCont is None and not plcMEV is None:
                            model.append([wp,plc,plcCBE,plcCont,plcMEV])
                           
        editable.append(True)
        editable.append(True)
        editable.append(True)
        editable.append(True)
        editable.append(True)
        prop.extend([PropertyEnum.NAME,PropertyEnum.NAME, PropertyEnum.VALUE, PropertyEnum.VALUE, PropertyEnum.VALUE])

        table = EditableTable("PEL Table for " + rootWorkpackage.getName(), model, headers, [editable], [prop], None)
        table.setEditableCol(editable)
        table.setWhatToShowCol(prop)
        table.prepareTable()
        
        docgenTable=Utils.getDBTableFromEditableTable(table,False)
        
        scriptOutput={"EditableTable": table}
        scriptOutput["DocGenOutput"]= [docgenTable]
#                            pelCsvList.append(wpName + ", " +
#                                              plcName + ", " +
#                                              str(plcCBE) + ", " +
#                                              str(plcCont) + ", " +
#                                              str(plcMEV) + "\n")
#        fileChooser = JFileChooser()
#        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY)
#        fileChooser.setDialogTitle("Save PEL at...")
#        retval = fileChooser.showSaveDialog(None)
#        if retval == JFileChooser.APPROVE_OPTION:
#            if fileChooser.getSelectedFile():
#                saveDir = fileChooser.getSelectedFile()
#                fileName = saveDir.toString() + ((os.name=='nt') and '\\' or '/') +"pelData.csv"
#                JOptionPane.showMessageDialog(None, "Saved the file at:\n" + fileName)
#                pelFile = open(fileName, 'w')
#                pelFile.writelines(pelCsvList)
#                pelFile.close()
    else:
        scriptOutput = "PEL Rollup is not valid."

