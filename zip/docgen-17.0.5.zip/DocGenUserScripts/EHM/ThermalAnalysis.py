### This script creates an editable table and a DocGen table presenting thermal
### information. It also performs an analysis of power values between items
### on the thermal loop and the replacement heater block. A total power must
### be supplied in a thermal loop characterization, and this script checks the
### power values of the replacement heater block across many mode scenarios,
### and where incorrect, it can write it the correct value.

### Author: David Coren, JPL


from com.nomagic.magicdraw.core import Application
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from com.nomagic.magicdraw.openapi.uml import SessionManager
from com.nomagic.magicdraw.openapi.uml import ModelElementsManager
from com.nomagic.uml2.ext.jmi.helpers import ModelHelper
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import Enumeration
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import AggregationKindEnum
from com.nomagic.uml2.ext.magicdraw.compositestructures.mdports import Port
from com.nomagic.magicdraw.teamwork.application import TeamworkUtils
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Lifeline
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import StateInvariant
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Interaction
from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import State
from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import Region

from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import ElementValue
from com.nomagic.uml2.ext.magicdraw.commonbehaviors.mdsimpletime import DurationConstraint
from gov.nasa.jpl.mel import ModelLib

from javax.swing import JOptionPane
from javax.swing import JCheckBox
from java.lang import Object
from jarray import array
import sys
import traceback
import os

from gov.nasa.jpl.mbee.lib import Utils
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTable
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBText
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBColSpec
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTableEntry
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBParagraph
from gov.nasa.jpl.mbee import DocGenUtils
from gov.nasa.jpl.mel import PELTable as PELTablej
from gov.nasa.jpl.mgss.mbee.docgen.table import EditableTable
from gov.nasa.jpl.mgss.mbee.docgen.table import PropertyEnum

from EHM import PELUtils
reload(PELUtils)
from EHM import PELRollup as Rollup
reload(Rollup)

from EHM import ThermalUtils as TA
reload(TA)

gl = Application.getInstance().getGUILog()
project = Application.getInstance().getProject()
ef = project.getElementsFactory()
mem = ModelElementsManager.getInstance()

model = []      #this is for the editable table body
headers = []    #this is for the editable table header
editable = []   #this is whether the table columns are editable
prop = []       #this is what should be edited for each column

scriptOutput = None

product = None
workpackage = None


targets = scriptInput['DocGenTargets']

importedModes = []
for t in targets:  #separate out the top product and workpackage
    if ModelLib.isPLProduct(t):
        product = t
    elif ModelLib.isWorkPackage(t):
        workpackage = t
    elif StereotypesHelper.hasStereotypeOrDerived(t, "Mode Scenario"):
        importedModes.append(t)
        
if len(importedModes) == 0:
    for behavior in product.getOwnedBehavior():
        if StereotypesHelper.hasStereotypeOrDerived(behavior, "Mode Scenario"):
            importedModes.append(behavior)
            
importedModes.sort()
model = []


fix = False
if not "FixMode" in scriptInput:
    fix = not Utils.getUserYesNoAnswer("Validate only?")

if "FixMode" in scriptInput and scriptInput["FixMode"] != "FixNone":
    fix = True
if product is None or workpackage is None:
    scriptOutput = "product or workpackage missing"
else:
    scriptOutput = {}
    plps = TA.getOwnedPLPs(product)    # list of uml::Properties
    suppliedproducts = TA.getSuppliedProducts(workpackage) # list of uml::Classes
    leafplps = TA.getOwnedLeafPLPs(product) # list of uml::Properties

    #find products both supplied and deployed
    targetitems = []
    
    #p is a uml::Property
    for p in plps:
        if p.getType() in suppliedproducts:
            targetitems.append(p)

    tp_mult = {}

    targetleafitems = [] # possibly unused
    
    # add check on multiplicities
    
    for p in leafplps:
        if p.getType() in suppliedproducts:
            targetleafitems.append(p)
        tp_mult[p] = float(p.getUpper())

    thermal_prods = filter(lambda x: StereotypesHelper.hasStereotypeOrDerived(x.getType(), StereotypesHelper.getStereotype(project, "Thermal Load Product")), targetitems)
    thermal_prods.sort()

    #identify replacement heater block
    RHB = []
    RHB_exists = True
    for t in thermal_prods:
        if StereotypesHelper.hasStereotypeOrDerived(t.getType(), StereotypesHelper.getStereotype(project, "Replacement Heater Block")) is True:
            RHB.append(t)
    if len(RHB) == 0:
        gl.log("Replacement Heater Block is missing! The script will proceed without calculating values for it.")
        RHB_exists = False
    elif len(RHB) > 1:
        gl.log("Multiple Replacement Heater Blocks found! The script will fail to run.")
    if RHB_exists:
        RHB = RHB[0]

    #identify thermal loop element
    thermalloopchar = []
    for ownedelement in product.getPart(): #product is the top-level input to the analysis (normally the flight system)
        if StereotypesHelper.getStereotype(project, "Thermal Loop Characterization") in StereotypesHelper.getStereotypes(ownedelement.getType()): # needs cleanup
            thermalloopchar.append(ownedelement)
    if len(thermalloopchar) != 1:
        gl.log("Check that the Thermal Loop Characterization is owned by the flight system! Also make sure there's only one!")
    else:
        thermalloopchar = thermalloopchar[0]

        #remove RHB
        if RHB_exists:
            thermal_prods = filter(lambda x: x!=RHB, thermal_prods)
        loop_power_leaves = []
        for tp in thermal_prods:
            if TA.ownsPLPs(tp.getType()) is False:
                loop_power_leaves.append(tp) # this is a list (potentially of lists) of PLPs
            if TA.ownsPLPs(tp.getType()) is True:
                loop_power_leaves.append(TA.getOwnedLeafPLPs(tp.getType()))
            eff_prop = PELUtils.findProperty(PELUtils.findProperty(tp.getType(), "Thermal Load Characterization").getType(), "Fraction of energy dissipated on loop")
            notes = ModelHelper.getComment(eff_prop.getOwner())
            eff = float(eff_prop.getDefault()) # should check that eff_prop.getDefault() is a number
            row = []
            row.append(tp.getType().getName() + " (" + tp.getName() + ")")
            row.append(eff_prop)
            row.append(notes)
            model.append(row)
        req_power = float(PELUtils.findProperty(thermalloopchar.getType(), "required thermal power").getDefault())

        # for logging
        req_power_type = PELUtils.findProperty(thermalloopchar.getType(), "required thermal power").getType().getName()
        gl.log("Loop energy required: " + str(req_power) + req_power_type)
        RHBrow = []
        RHBeff = float(1)
        if RHB_exists:
            RHB_behavior = RHB.getType().getClassifierBehavior() # must be a statemachine
            RHBeffprop = PELUtils.findProperty(PELUtils.findProperty(RHB.getType(), "Thermal Load Characterization").getType(), "Fraction of energy dissipated on loop")
            RHBeff = float(RHBeffprop.getDefault())
            RHBrow.append(RHB.getType().getName() + " (" + RHB.getName() + ")" )
            RHBrow.append(RHBeffprop)
            RHBrow.append(ModelHelper.getComment(RHB.getType()))
        for mode in importedModes:
            loop_power = float(0) #loop power CBE
            loop_MEV = float(0) #loop power MEV
            ii = 0
            for lps in loop_power_leaves:
                if type(lps) is list:
                    assembly = thermal_prods[ii]
                    assembly_power = 0
                    assembly_MEV = 0
                    row = model[ii] #filter(lambda x: assembly.getType().getName() + " (" + assembly.getName() + ")" == x[0], model)
                    eff_prop = row[1]
                    eff = float(eff_prop.getDefault())
                    for ee in lps:
                        lifeline = PELUtils.findLifelineIncludingInherited(mode, ee)
                        if len(lifeline.getCoveredBy()) == 1:
                            plc = PELUtils.getPLCForState(lifeline.getCoveredBy()[0].getInvariant().getSpecification().getElement())
                            ee_power = float(PELUtils.findProperty(plc, "steady-state power CBE").getDefault())
                            ee_MEV = float(PELUtils.findProperty(plc, "steady-state power MEV").getDefault())
                        else:
                            ee_power = float(0)
                            ee_MEV = float(0)
                            for state in lifeline.getCoveredBy():
                                dutyCycle = float(state.get_constraintOfConstrainedElement()[0].getSpecification().getMin().getExpr().getValue().split("%")[0])/100
                                plc = PELUtils.getPLCForState(state.getInvariant().getSpecification().getElement())
                                ee_power += dutyCycle * float(PELUtils.findProperty(plc, "steady-state power CBE").getDefault())
                                ee_MEV += dutyCycle * float(PELUtils.findProperty(plc, "steady-state power MEV").getDefault())
                        mult = 1
                        if tp_mult[ee] is not None:
                            mult = tp_mult[ee]
                        loop_power += ee_power * eff * mult
                        loop_MEV += ee_MEV * eff * mult
                        assembly_power += ee_power * eff * mult
                        assembly_MEV += ee_MEV * eff * mult
                    row.extend([str(assembly_power), str(assembly_MEV)])
                else:
                    row = model[ii] #filter(lambda x: lps.getType().getName() + " (" + lps.getName() + ")" == x[0], model)
                    eff_prop = row[1]
                    eff = float(eff_prop.getDefault())
                    lifeline = PELUtils.findLifelineIncludingInherited(mode, lps)
                    if len(lifeline.getCoveredBy()) == 1:
                        plc = PELUtils.getPLCForState(lifeline.getCoveredBy()[0].getInvariant().getSpecification().getElement())
                        lps_power = float(PELUtils.findProperty(plc, "steady-state power CBE").getDefault())
                        lps_MEV = float(PELUtils.findProperty(plc, "steady-state power MEV").getDefault())
                    else:
                        lps_power = float(0)
                        lps_mev = float(0)
                        for state in lifeline.getCoveredBy():
                            dutyCycle = float(state.get_constraintOfConstrainedElement()[0].getSpecification().getMin().getExpr().getValue().split("%")[0])/100
                            plc = PELUtils.getPLCForState(state.getInvariant().getSpecification().getElement())
                            lps_power += dutyCycle * float(PELUtils.findProperty(plc, "steady-state power CBE").getDefault())
                            lps_MEV += dutyCycle * float(PELUtils.findProperty(plc, "steady-state power MEV").getDefault())
                    mult = 1
                    if tp_mult[lps] is not None:
                        mult = tp_mult[lps]
                    loop_power += lps_power * eff * mult
                    loop_MEV += lps_MEV * eff * mult
                    row.extend([str(lps_power * eff), str(lps_MEV * eff)])
                ii+=1
            RHB_power = (req_power - loop_MEV) / RHBeff # this is the currently approved FSET formula (as of Oct 9 2013)
            RHB_MEV = (req_power - loop_power) / RHBeff # this is the currently approved FSET formula (as of Oct 9 2013)
            if RHB_power < 0:
                RHB_power = float(0)
            if RHB_MEV < 0:
                RHB_MEV = float(0)
            if RHB_exists:
                for om in RHB_behavior.getOwnedMember():
                    if isinstance(om, Region):
                        for sm in om.getOwnedMember():
                            if isinstance(sm, State):
                                sm = PELUtils.getPLCForState(sm)
                                if sm.getName() == mode.getName():
                                    RHB_power_prop = PELUtils.findProperty(sm, "steady-state power CBE")
                                    old_RHB_power = float(RHB_power_prop.getDefault())
                                    RHB_MEV_prop = PELUtils.findProperty(sm, "steady-state power MEV")
                                    old_RHB_MEV = float(RHB_MEV_prop.getDefault())
                                    RHB_cont_prop = PELUtils.findProperty(sm, "contingency")
                                    try:
                                        old_RHB_cont = float(RHB_cont_prop.getDefault())
                                        old_RHB_cont = round(old_RHB_cont, 12)
                                    except:
                                        old_RHB_cont = RHB_cont_prop.getDefault()
                                    if RHB_power != float(0):
                                        RHB_cont = (RHB_MEV - RHB_power)/RHB_power
                                        RHB_cont = round(RHB_cont, 12)
                                    elif RHB_MEV != float(0):
                                        RHB_cont = "n/a"
                                    else:
                                        RHB_cont = float(0)
                                    if round(RHB_power, 2) == round(old_RHB_power, 2):
                                        gl.log("Replacement Heater model value (" + str(old_RHB_power) + " W CBE) matches calculated value (" + str(RHB_power) + " W CBE) in the mode " + mode.getName() + ".")
                                    else:
                                        if fix == True:
                                            gl.log("Replacement Heater used to use " + str(old_RHB_power) + " W CBE in the mode " + mode.getName() + ". Setting it to " + str(RHB_power) + " W CBE...")
                                            if RHB_power_prop.isEditable():
                                                Utils.setPropertyValue(RHB_power_prop, str(RHB_power))
                                            else:
                                                gl.log(RHB_power_prop.getQualifiedName() + " is not locked!")
                                        else:
                                            gl.log("Replacement Heater currently uses " + str(old_RHB_power) + " W CBE in the mode " + mode.getName() + ". New calculated value is " + str(RHB_power) + " W CBE. This has not been written into the model.")
                                    if round(RHB_MEV, 2) == round(old_RHB_MEV, 2):
                                        gl.log("Replacement Heater model value (" + str(old_RHB_MEV) + " W MEV) matches calculated value (" + str(RHB_MEV) + " W MEV) in the mode " + mode.getName() + ".")
                                    else:
                                        if fix == True:
                                            gl.log("Replacement Heater used to use " + str(old_RHB_MEV) + " W MEV in the mode " + mode.getName() + ". Setting it to " + str(RHB_MEV) + " W MEV...")
                                            if RHB_MEV_prop.isEditable():
                                                Utils.setPropertyValue(RHB_MEV_prop, str(RHB_MEV))
                                            else:
                                                gl.log(RHB_MEV_prop.getQualifiedName() + " is not locked!")
                                        else:
                                            gl.log("Replacement Heater currently uses " + str(old_RHB_MEV) + " W MEV in the mode " + mode.getName() + ". New calculated value is " + str(RHB_MEV) + " W MEV. This has not been written into the model.")
                                    try:
                                        if round(RHB_cont, 2) != round(old_RHB_cont, 2):
                                            if RHB_cont_prop.isEditable() and fix == True:
                                                gl.log("Replacement Heater contingency currently is " + str(old_RHB_cont) + " in the mode " + mode.getName() + ". Setting it to " + str(RHB_cont) + "...")
                                                Utils.setPropertyValue(RHB_cont_prop, str(RHB_cont))
                                            elif RHB_cont_prop.isEditable() == False and fix == True:
                                                gl.log(RHB_cont_prop.getQualifiedName() + " is not locked!")
                                            elif fix == False:
                                                gl.log("Replacement Heater contingency currently is " + str(old_RHB_cont) + " in the mode " + mode.getName() + " but should be " + str(RHB_cont) + ". This has not been written into the model.")
                                    except:
                                        gl.log("For the contingency of the Replacement Heater in the mode " + mode.getName() + ", it could not be determined if it had changed.")
                                    try:
                                        RHB_power = round(RHB_power, 2)
                                    except:
                                        pass
                                    try:
                                        RHB_MEV = round(RHB_MEV, 2)
                                    except:
                                        pass
                                    RHBrow.extend([RHB_power, RHB_MEV])
            else:
                gl.log("System is thermally negative by CBE: " + str(RHB_power) + "W (MEV: " + str(RHB_MEV) + "W) in the mode " + mode.getName())
        model2 = []
        model3 = []
        model2.append(RHBrow)
        pretotalrow = ["Total thermal power on loop without heater", "", ""]
        totalrow = []
        totalrow.append("Total thermal power on loop")
        totalrow.append("")
        totalrow.append("Required power: " + str(req_power) + "W")
        i = 3
        for mode in importedModes:
            loop_total = 0
            loop_totalMEV = 0
            for row in model:
                loop_total += float(row[i])
                loop_totalMEV += float(row[i+1])
            pretotalrow.append(round(loop_total, 2))
            pretotalrow.append(round(loop_totalMEV,2))
            if RHB_exists:
                loop_total += RHBrow[i]
                loop_totalMEV += RHBrow[i+1]
            totalrow.append(round(loop_total, 2))
            totalrow.append(round(loop_totalMEV, 2))
            i+=2
        model2.append(totalrow)
        model3.append(pretotalrow)
        model3.extend(model)
        headers = ["Items on the thermal loop", "Heat Transfer Coefficient", "Notes"]
        dbheader1 = []
        dbheader1b = []
        headers2 = ["","Heat Transfer Coefficient", "Notes"]
        lnn = DBTableEntry()
        lnn.addElement(DBText(""))
        lnn.setMorerows(1)
        dbheader1.append(lnn)
        dbheader1b.append(lnn)
        dbheader2 = []
        dbheader2b = []
        colspec  = []
        for h in headers:
            ln = DBTableEntry()
            ln.addElement(DBText(h))
            ln.setMorerows(1)
            dbheader1.append(ln)
        for hh in headers2:
            lln = DBTableEntry()
            lln.addElement(DBText(hh))
            lln.setMorerows(1)
            dbheader1b.append(lln)
        editable = [False, True, False]
        prop = [PropertyEnum.VALUE, PropertyEnum.VALUE, PropertyEnum.VALUE]
        for mode in importedModes:
            headers.append("Thermal CBE Power added in " + mode.getName())
            editable.append(False)
            prop.append(PropertyEnum.VALUE)
            headers.append("Thermal MEV Power added in " + mode.getName())
            editable.append(False)
            m = DBTableEntry()
            m.addElement(DBText(mode.getName() + " Thermal loop power added"))
            colnum = int(importedModes.index(mode))*2 + 3
            m.setNamest(str(colnum))
            m.setNameend(str(colnum + 1))
            colspec.extend([DBColSpec(colnum), DBColSpec(colnum+1)])
            dbheader1.append(m)
            dbheader1b.append(m)
            dbheader2.extend([DBText("CBE [W] per unit"), DBText("MEV [W] per unit")])
            dbheader2b.extend([DBText("Min [W]"), DBText("Max [W]")])
            prop.append(PropertyEnum.VALUE)
        table = EditableTable("Thermal Loop Heat Information", model3, headers, None, None, None)
        table.setEditableCol(editable)
        table.setWhatToShowCol(prop)
        table.prepareTable()
        dbheaders = [dbheader1, dbheader2]
        dbheaders2 = [dbheader1, dbheader2b]
        scriptOutput["EditableTable"] = table
        docgenTable = Utils.getDBTableFromEditableTable(table, True)
        docgenTable.setColspecs(colspec)
        docgenTable.setHeaders(dbheaders)
        if RHB_exists:
            table2 = EditableTable("Replacment Heater and Thermal Totals", model2, headers, None, None, None)
            table2.setEditableCol(editable)
            table2.setWhatToShowCol(prop)
            table2.prepareTable()
            docgenTable2 = Utils.getDBTableFromEditableTable(table2, True)
            docgenTable2.setColspecs(colspec)
            docgenTable2.setHeaders(dbheaders2)
            scriptOutput["DocGenOutput"] = [docgenTable2, docgenTable]
        else:
            gl.log("Replacement Heater Block not found, power values for it were not calcualted.")
            scriptOutput["DocGenOutput"] = [docgenTable]