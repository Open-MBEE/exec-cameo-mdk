### This code creates an editable table and DocGen table presenting thermal
### information. It is a power mode list of all the powered items on the
### spacecraft, but it adds columns with thermal information.

### Author: David Coren, JPL

from com.nomagic.magicdraw.core import Application
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from com.nomagic.magicdraw.openapi.uml import SessionManager
from com.nomagic.magicdraw.openapi.uml import ModelElementsManager
from com.nomagic.uml2.ext.jmi.helpers import ModelHelper
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import Enumeration
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import AggregationKindEnum
from com.nomagic.uml2.ext.magicdraw.compositestructures.mdports import Port
from com.nomagic.magicdraw.teamwork.application import TeamworkUtils
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Lifeline
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import StateInvariant
from com.nomagic.uml2.ext.magicdraw.interactions.mdbasicinteractions import Interaction
from com.nomagic.uml2.ext.magicdraw.statemachines.mdbehaviorstatemachines import State
from com.nomagic.uml2.ext.magicdraw.classes.mdkernel import ElementValue
from com.nomagic.uml2.ext.magicdraw.commonbehaviors.mdsimpletime import DurationConstraint
from gov.nasa.jpl.mel import ModelLib

from javax.swing import JOptionPane
from javax.swing import JCheckBox
from java.lang import Object
from jarray import array
import sys
import traceback
import os

from gov.nasa.jpl.mbee.lib import Utils
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTable
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBText
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBColSpec
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBTableEntry
from gov.nasa.jpl.mgss.mbee.docgen.docbook import DBParagraph
from gov.nasa.jpl.mbee import DocGenUtils
from gov.nasa.jpl.mel import PELTable as PELTablej
from gov.nasa.jpl.mgss.mbee.docgen.table import EditableTable
from gov.nasa.jpl.mgss.mbee.docgen.table import PropertyEnum

from EHM import PELUtils
reload(PELUtils)
from EHM import PELRollup as Rollup
reload(Rollup)
from EHM import ThermalUtils as TA
reload(TA)

gl = Application.getInstance().getGUILog()
project = Application.getInstance().getProject()
ef = project.getElementsFactory()
mem = ModelElementsManager.getInstance()

model = []      #this is for the editable table body
headers = []    #this is for the editable table header
editable = []   #this is whether the table columns are editable
prop = []       #this is what should be edited for each column

scriptOutput = None

product = None
workpackage = None


targets = scriptInput['DocGenTargets']

showStates = scriptInput['showStates'][0]
if showStates is None:
    showStates = False # changed default behavior to false from true

importedModes = []
for t in targets:  #separate out the top product and workpackage
    if ModelLib.isPLProduct(t):
        product = t
    elif ModelLib.isWorkPackage(t):
        workpackage = t

if product is None or workpackage is None:
    scriptOutput = "product or workpackage missing"
else:
    scriptOutput = {}
    plps = TA.getOwnedPLPs(product)
    suppliedproducts = TA.getSuppliedProducts(workpackage)
    leafplps = TA.getOwnedLeafPLPs(product)

    #find products both supplied and deployed
    targetitems = []
    for p in plps:
        if p.getType() in suppliedproducts:
            targetitems.append(p)

    targetleafitems = []
    targetleaftypes = []
    for p in leafplps:
        if p.getType() in suppliedproducts:
            targetleafitems.append(p)
            if p.getType() not in targetleaftypes:
                targetleaftypes.append(p.getType())

    thermal_prods = filter(lambda x: StereotypesHelper.hasStereotypeOrDerived(x.getType(), StereotypesHelper.getStereotype(project, "Thermal Load Product")), targetitems)
    loop_power_leaves = []
    for tp in thermal_prods:
        if TA.ownsPLPs(tp.getType()) is False:
            loop_power_leaves.append(tp)
        if TA.ownsPLPs(tp.getType()) is True:
            loop_power_leaves.append(TA.getOwnedLeafPLPs(tp.getType()))

    row_one = [workpackage.getName()]
    row_one.extend(["","","","","","",""])

    model.append(row_one)

    # dictionary definitions
    onLoop = {} # property => bool #not used
    eff = {} # class => float
    eff_prop = {} # class => property
    notes = {} # class => documentation
    
    # not shown when showStates = false
    states = {} # class => list of PLC
    cbesT = {} # class => contribution of thermal loop
    mevsT = {} # class => contribution of thermal loop
    
    for ll in targetleaftypes:
        plcs = sorted(ll.getClassifierBehavior().getOwnedBehavior())
        states[ll] = []
        if showStates is True:
            for plc in plcs:
                states[ll].append(plc)
    for tt in sorted(loop_power_leaves):
        if type(tt) is list:
            assembly = filter(lambda x: TA.getOwnedLeafPLPs(x.getType()) == tt , thermal_prods)[0]
            for ee in tt:
                eff_prop[ee.getType()] = PELUtils.findProperty(PELUtils.findProperty(assembly.getType(), "Thermal Load Characterization").getType(), "Fraction of energy dissipated on loop")
                eff[ee.getType()] = float(eff_prop[ee.getType()].getDefault())
                if len(ModelHelper.getComment(eff_prop[ee.getType()].getOwner())) > 0:
                    notes[ee.getType()] = "Connects to loop via " + assembly.getType().getName() + " - " + str(ModelHelper.getComment(eff_prop[ee.getType()].getOwner()))
                else:
                    notes[ee.getType()] = "Connects to loop via " + assembly.getType().getName()
                cbesT[ee.getType()] = []
                mevsT[ee.getType()] = []
                for plc in states[ee.getType()]:
                    cbesT[ee.getType()].append(round(float(PELUtils.findProperty(plc, "steady-state power CBE").getDefault())*eff[ee.getType()], 2))
                    mevsT[ee.getType()].append(round(float(PELUtils.findProperty(plc, "steady-state power MEV").getDefault())*eff[ee.getType()], 2))
        else:
            eff_prop[tt.getType()] = PELUtils.findProperty(PELUtils.findProperty(tt.getType(), "Thermal Load Characterization").getType(), "Fraction of energy dissipated on loop")
            eff[tt.getType()] = float(eff_prop[tt.getType()].getDefault())
            if len(ModelHelper.getComment(eff_prop[tt.getType()].getOwner())) > 0:
                notes[tt.getType()] = "Connects directly to loop - " + str(ModelHelper.getComment(eff_prop[tt.getType()].getOwner()))
            else:
                notes[tt.getType()] = "Connects directly to loop"
            cbesT[tt.getType()] = []
            mevsT[tt.getType()] = []

            for plc in states[tt.getType()]:
                cbesT[tt.getType()].append(round(float(PELUtils.findProperty(plc, "steady-state power CBE").getDefault())*eff[tt.getType()], 2))
                mevsT[tt.getType()].append(round(float(PELUtils.findProperty(plc, "steady-state power MEV").getDefault())*eff[tt.getType()], 2))
    for authWP1 in sorted(TA.getAuthorizedWPs(workpackage)):
        wp1row = ["> " + authWP1.getName(), "","","",""]
        if showStates is True:
            wp1row.extend(["","",""])
        model.append(wp1row)
        for authWP in sorted(TA.getAuthorizedWPs(authWP1)):
            wpParts = TA.getSuppliedProducts(authWP)
            wprow = []
            wprow.append("> > " + authWP.getName())
            wprow.extend(["","","",""])
            if showStates is True:
                wprow.extend(["","",""])
            model.append(wprow)
            for tl in targetleaftypes:
                if tl in wpParts:
                    row = []
                    row.append("")
                    row.append(tl.getName())
                    if eff.get(tl, "n/a") == "n/a":
                        row.append("NO")
                    else:
                        row.append("YES")
                    row.append(eff.get(tl, "n/a"))
                    if showStates is True:
                        row.append(states[tl][0])
                        na = ["n/a"]
                        row.append(cbesT.get(tl, na)[0])
                        row.append(mevsT.get(tl, na)[0])
                    row.append(notes.get(tl, ""))
                    model.append(row)
                    if showStates is True:
                        i=1
                        for plc in states[tl][1:]:
                            na.append("n/a")
                            nrow = ["","","",""]
                            nrow.append(plc)
                            nrow.append(cbesT.get(tl, na)[i])
                            nrow.append(mevsT.get(tl, na)[i])
                            nrow.append("")
                            model.append(nrow)
                            i+=1
                        
    headers = ["Work Package", "Product", "Connected to loop?", "Heat Transfer Coefficient"]
    editable = [False, False, False, False] 
    prop = [PropertyEnum.VALUE, PropertyEnum.NAME, PropertyEnum.VALUE, PropertyEnum.VALUE]
    if showStates is True:
        headers.extend(["States", "Thermal power contributed at CBE electrical power [W]", "Thermal power contributed at MEV electrical power [W]"])
        prop.extend([PropertyEnum.NAME, PropertyEnum.VALUE, PropertyEnum.VALUE])
        editable.extend([False, False, False])
    headers.append("Notes")
    prop.append(PropertyEnum.VALUE)
    editable.append(False)
    table = EditableTable("Power Mode List with Thermal Information", model, headers, [editable], [prop], None)
    table.prepareTable()
    dbheaders = [DBText('')]
    for dbh in headers:
        dbheaders.append(DBText(dbh))
    docgenTable = Utils.getDBTableFromEditableTable(table, True)
    docgenTable.setHeaders([dbheaders])
    scriptOutput['EditableTable'] = table
    scriptOutput['DocGenOutput'] = [docgenTable]
